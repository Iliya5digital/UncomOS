void uevent_init(void);
