gboolean release_checker_init (UpgradeNotifier *un);
