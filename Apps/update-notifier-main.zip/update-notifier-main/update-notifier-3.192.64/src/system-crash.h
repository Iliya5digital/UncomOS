#include "update-notifier.h"
#define CRASHREPORT_REPORT_APP "/usr/share/apport/apport-gtk"
