#include "update-notifier.h"

gboolean cdroms_init (UpgradeNotifier *un);
