gboolean crashreport_check (TrayApplet *ta);
void crashreport_tray_icon_init (TrayApplet *ta);
