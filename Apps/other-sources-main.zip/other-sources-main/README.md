# other-sources
This package containes URL of other sources used to create OS build. You can find them by link [here](https://disk.yandex.ru/d/SuvgVJkdSNberQ).
