#!/bin/bash

Green='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${Green}Starting the script...${NC}"
if [[ -f /etc/udev/rules.d/61-gdm.rules ]]
    # User has his own override
    then cp /etc/udev/rules.d/61-gdm.rules /etc/udev/rules.d/61-gdm.rules.bak
    # Default situation
    else
        cp /lib/udev/rules.d/61-gdm.rules /etc/udev/rules.d/61-gdm.rules
fi
sed -i "s/RUN+=\"\/usr\/libexec\/gdm-runtime-config set daemon PreferredDisplayServer xorg\"/#RUN+=\"\/usr\/libexec\/gdm-runtime-config set daemon PreferredDisplayServer xorg\"/" /etc/udev/rules.d/61-gdm.rules
sed -i "s/RUN+=\"\/usr\/libexec\/gdm-runtime-config set daemon WaylandEnable false\"/#RUN+=\"\/usr\/libexec\/gdm-runtime-config set daemon WaylandEnable false\"/" /etc/udev/rules.d/61-gdm.rules

