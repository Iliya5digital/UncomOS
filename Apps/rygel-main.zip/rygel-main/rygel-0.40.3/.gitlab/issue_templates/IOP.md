### Which device are you experiencing problems with?

### Which issues do you see?

[x] Adding the device to `force_downgrade_for` made it working
<!-- Remove the line above if it did not -->

<!-- Please do not modify anything after here -->

/label ~"5. Iop"
/label ~"1. Bug"
