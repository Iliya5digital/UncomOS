============================
NEWS for janitor.plugincore
============================

1.0 (2012-XX-XX)
================
 * Initial release since refactoring into a separate package.
