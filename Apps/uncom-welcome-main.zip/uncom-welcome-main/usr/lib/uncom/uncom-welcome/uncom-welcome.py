#!/usr/bin/python3
import json
import gi
import os
import subprocess
import gettext
import locale
import message_dialog

gi.require_version("WebKit2", "4.0")
from gi.repository import WebKit2
import gi.repository.GLib as GLib

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gio, Gdk, GdkPixbuf, Pango

locale_path = "/usr/share/uncom/uncom-welcome/locale"
text_domain = "uncom-welcome"
gettext.install(text_domain, locale_path)
from locale import gettext as _
locale.bindtextdomain(text_domain, locale_path)
locale.textdomain(text_domain)

ui_file_path = '/usr/share/uncom/uncom-welcome/uncom-welcome.ui'
config_file_path = "/usr/share/uncom/uncom-welcome/config.json"
pages_dir_path = "/usr/share/uncom/uncom-welcome/pages"

class TableOfContentItem(Gtk.ListBoxRow):
    def __init__(self, uri, item_name, item_text, icon_name):
        Gtk.ListBoxRow.__init__(self)
        self.uri = uri
        self.set_name(item_name)
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.set_border_width(6)
        image = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        box.pack_start(image, False, False, 0)
        label = Gtk.Label(xalign=0)
        label.set_text(_(item_text))
        label.set_tooltip_text(_(item_text))
        label.set_width_chars(32)
        label.set_ellipsize(Pango.EllipsizeMode.END)
        box.pack_start(label, False, False, 0)
        self.add(box)

    def launch(self, button, command):
        button.set_sensitive(False)
        subprocess.Popen([command])
        GLib.timeout_add_seconds(self.button_cooldown_time, self.enable_launch_button, button)

    def enable_launch_button(self, button):
        button.set_sensitive(True)


class UncomWelcome():
    def __init__(self):
        # WebKit2.WebView.set_settings(WebKit2.WebView().get_settings().set_enable_private_browsing(True))
        WebKit2.WebView()
        self.builder = Gtk.Builder()
        self.builder.set_translation_domain(text_domain)
        self.builder.add_from_file(ui_file_path)

        self.window = self.builder.get_object("main_window")
        self.window.set_icon_name("uncom-welcome")
        self.window.set_position(Gtk.WindowPosition.CENTER)
        self.window.connect("destroy", Gtk.main_quit)

        # Setup the main stack

        self.webview = WebKit2.WebView()
        page_name = "page0"
        self.webview.set_name(page_name)

        widget = self.builder.get_object("center_box")
        if widget is not None:
            widget.pack_start(self.webview, True, True, 0)

        self.webview.connect("decide-policy", self.on_decide_policy)


        # Construct the stack switcher
        self.list_box = self.builder.get_object("list_navigation")

        self.build_table_of_content()

        self.list_box.connect("row-activated", self.sidebar_row_selected_cb)

        self.show_item("welcome")

        self.update_os_activation_status()

        #window.set_default_size(800, 500)
        self.window.set_size_request(800, 500)
        self.window.show_all()

    def on_decide_policy(self, webview, decision, decision_type):
        if decision_type != WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
            return
        uri = decision.get_navigation_action().get_request().get_uri()
        if uri.startswith("http://") or uri.startswith("https://"):
            try:
                subprocess.Popen(["xdg-open", uri])
            except Exception as ex:
                print(f"An unexpected error occurred: {ex}")
            decision.ignore()
        elif uri.startswith("launch://"):
            try:
                subprocess.Popen([uri[9:]])
            except Exception as ex:
                print(f"An unexpected error occurred: {ex}")
            decision.ignore()
        elif uri.startswith("check://"):
            if not self.is_os_activated:
                message_dialog.show_msg_dialog(_("Seems Uncom OS isn't activated."), _("This action can't be done"), [_("Cancel"), Gtk.ResponseType.CANCEL, _("Activate"), Gtk.ResponseType.APPLY], self.window, self.on_activate_clicked)
            else:
                try:
                    subprocess.Popen(["xdg-open", uri.replace("check://", "https://")])
                except Exception as ex:
                    print(f"An unexpected error occurred: {ex}")
            decision.ignore()

    def on_activate_clicked(self, response):
        if response == Gtk.ResponseType.APPLY:
            try:
                subprocess.Popen("/usr/bin/uncom-activate")
            except Exception as ex:
                print(f"An unexpected error occurred: {ex}")

    def build_table_of_content(self):
        language, encoding = locale.getdefaultlocale()
        lang_code = language[:2]
        with open(config_file_path) as f:
            config = json.load(f)
        if config is None:
            return
        for page_config in config['pages']:
            #print(page_config)
            page_name = page_config.get('name')
            page_title = page_config.get('title')
            if page_title is None:
                continue
            page_icon = page_config.get('icon')
            config_uri = page_config['uri']
            uri = config_uri
            if not uri.startswith("http"):
                page_file_name = f"{pages_dir_path}/{lang_code}/{config_uri}"
                if not os.path.isfile(page_file_name):
                    page_file_name = f"{pages_dir_path}/ru/{config_uri}"
                uri = f"file:///{page_file_name}"

            self.list_box.add(TableOfContentItem(uri, page_name, page_title, page_icon))

    def show_item(self, item_name):
        for row in self.list_box.get_children():
            if row.get_name() == item_name:
                self.webview.load_uri(row.uri)
                break

    def sidebar_row_selected_cb(self, list_box, row):
        self.webview.load_uri(row.uri)

    def update_os_activation_status(self):
        self.is_os_activated = subprocess.call(["/usr/bin/uncom-activate --check-license-bg"], shell=True,
                                               universal_newlines=True) == 0



if __name__ == "__main__":
    UncomWelcome()
    Gtk.main()
