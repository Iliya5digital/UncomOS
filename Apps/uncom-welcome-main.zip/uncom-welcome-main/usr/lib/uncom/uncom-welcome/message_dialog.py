import gi
gi.require_version('Gtk', '3.0')
from gi.repository import GLib, Gtk, GObject, Gdk, XApp, Pango

def show_msg_dialog(message, title, buttons:list, parent_window=None, callback=None):
    Gdk.threads_add_idle(GLib.PRIORITY_DEFAULT_IDLE, _show_info_msg_dialog, message, title, buttons, parent_window, callback)

def _show_info_msg_dialog(message_text, title, buttons:list, parent_window, callback=None):

    dialog = Gtk.MessageDialog(
        transient_for=parent_window,
        flags=0,
        message_type=Gtk.MessageType.INFO,
        buttons=Gtk.ButtonsType.NONE,
        text=message_text
    )

    if parent_window is not None:
        dialog.set_transient_for(parent_window)
        dialog.set_modal(True)
        parent_window.set_sensitive(False)

    dialog.format_secondary_text(title)

    # Add icon
    image = Gtk.Image.new_from_icon_name("dialog-information", Gtk.IconSize.DIALOG)
    dialog.set_image(image)

    # Add buttons
    dialog.add_buttons(*buttons)

    # Show the dialog
    dialog.show_all()

    # Run the dialog and handle the response
    response = dialog.run()

    if parent_window is not None:
        parent_window.set_sensitive(True)

    # Close the dialog
    dialog.destroy()

    if parent_window is not None:
        callback(response)

    return GLib.SOURCE_REMOVE

