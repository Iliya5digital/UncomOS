# Uncominstall

Software Manager for Uncom OS.

![image](https://user-images.githubusercontent.com/19881231/122644976-86767180-d120-11eb-9cf4-eed2813f749b.png)

## Build
Get source code
```
git clone https://git.uncom.tech/uncom-os/apps/uncominstall.git
cd uncominstall
```
Build
```
dpkg-buildpackage --no-sign
```
Install
```
cd ..
sudo dpkg -i uncominstall*.deb
```

