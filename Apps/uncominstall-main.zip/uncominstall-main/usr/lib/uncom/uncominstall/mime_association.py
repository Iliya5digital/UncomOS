import os
from gi.repository import GLib

def get_mimeapps_list_path():
    return os.path.join( GLib.get_user_config_dir(), "mimeapps.list")

def add_local_mime_type(mime_type, app_name):
    add_config_value(get_mimeapps_list_path(), "Added Associations", mime_type, f"{app_name}.desktop")

def remove_local_mime_type(mime_type, app_name):
    remove_config_value(get_mimeapps_list_path(), "Added Associations", mime_type, f"{app_name}.desktop")

def add_config_value(file_path, section_name, key, value):
    config = read_mimeapps_file(file_path)
    if config is None:
        config = {}
    section = config.get(section_name)
    if section is None:
        config[section_name] = {}
        section = config[section_name]
    if key in section:
        values = section.get(key)
        if value not in values:
            values.append(value)
    else:
        section[key] = [value]
    write_mimeapps_file(file_path, config)

def remove_config_value(file_path, section_name, key, value):
    config = read_mimeapps_file(file_path)
    if config is None:
        config = {}
    section = config.get(section_name)
    if section is not None:
        config[section_name] = {}
        section = config[section_name]
    values = section.get(key)
    if values is not None:
        if value in values:
            while value in values:
                values.remove(value)
            if len(values) == 0:
                section.pop(key, None)
    write_mimeapps_file(file_path, config)
def read_mimeapps_file(file_path):
    config = {}
    current_section = None

    try:
        with open(file_path, 'r') as file:
            for line in file:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if line.startswith('[') and line.endswith(']'):
                    section_name = line[1:-1]
                    config[section_name] = {}
                    current_section = config[section_name]
                elif '=' in line and current_section is not None:
                    key, formatted_values = map(str.strip, line.split('=', 1))
                    values = current_section.get(key)
                    if values is not None:
                        new_values = map(str.strip, formatted_values.split(';'))
                        new_values = list(filter(None, new_values))
                        values.extend(new_values)
                    else:
                        new_values = map(str.strip, formatted_values.split(';'))
                        new_values = list(filter(None, new_values))
                        current_section[key] = new_values
        return config

    except Exception as e:
        print(f"Error reading config file   {file_path}: {e}")
        return None

def write_mimeapps_file(file_path, config):
    try:
        with open(file_path, 'w') as file:
            for section_name, section in config.items():
                file.write(f"[{section_name}]\n")
                for key, values in section.items():
                    new_values = map(str.strip, values)
                    new_values = list(filter(None, new_values))
                    formatted_values = ';'.join(new_values)
                    file.write(f"{key}={formatted_values}\n")
                file.write('\n')
    except Exception as e:
        print(f"Error writing config file {file_path}: {e}")