import os
import threading
import urllib.request
import requests
import constants

from gi.repository import Gio, GLib

SCREENSHOT_UNCOM_URL = "https://download.uncom.tech/uncom-install/screenshots/%s.png"
SCREENSHOT_UNCOM2_URL = "https://download.uncom.tech/uncom-install/screenshots/%s-%s.png"
SCREENSHOT_DEBIAN_URL = "http://screenshots.debian.net/package/%s"
THUMBNAIL_DEBIAN_URL = "http://screenshots.debian.net/%s"


class ScreenshotDownloader(threading.Thread):
    def __init__(self, application, pkginfo):
        threading.Thread.__init__(self)
        self.application = application
        self.pkginfo = pkginfo
        self.settings = Gio.Settings(schema_id="com.linuxmint.install")

    def prefix_media_base_url(self, url):
        if (not url.startswith("http")) and self.pkginfo.remote == "flathub":
            return constants.FLATHUB_MEDIA_BASE_URL + url
        return url

    def run(self):
        num_screenshots = 0
        self.application.screenshots = []
        # Add main screenshot

        if self.pkginfo.pkg_hash.startswith("f"):
            try:
                # Add additional screenshots from AppStream
                if len(self.application.installer.get_screenshots(self.pkginfo)) > 0:
                    for screenshot in self.pkginfo.screenshots:

                        image = screenshot.get_image(624, 351)

                        url = self.prefix_media_base_url(image.get_url())
                        if requests.head(url, timeout=5).status_code < 400:
                            num_screenshots += 1

                            local_name = os.path.join(constants.SCREENSHOT_DIR, "%s_%s.png" % (self.pkginfo.name, num_screenshots))

                            source = screenshot.get_source()

                            source_url = self.prefix_media_base_url(source.get_url())
                            self.save_to_file(url, source_url, local_name)

                            self.add_screenshot(self.pkginfo, local_name, num_screenshots)
            except Exception as e:
                print(e)

            if num_screenshots == 0:
                self.add_screenshot(self.pkginfo, None, 0)

            return
        try:
            link = SCREENSHOT_UNCOM_URL % self.pkginfo.name
            if requests.head(link, timeout=5).status_code < 400:
                num_screenshots += 1

                local_name = os.path.join(constants.SCREENSHOT_DIR, "%s_%s.png" % (self.pkginfo.name, num_screenshots))
                self.save_to_file(link, None, local_name)

                self.add_screenshot(self.pkginfo, local_name, num_screenshots)
        except Exception as e:
            print(e)

        screenshot_index = 1
        while True:
            try:
                link = SCREENSHOT_UNCOM2_URL % (self.pkginfo.name, screenshot_index)
                if requests.head(link, timeout=5).status_code < 400:
                    num_screenshots += 1
                    screenshot_index += 1

                    local_name = os.path.join(constants.SCREENSHOT_DIR, "%s_%s.png" % (self.pkginfo.name, num_screenshots))
                    self.save_to_file(link, None, local_name)

                    self.add_screenshot(self.pkginfo, local_name, num_screenshots)
                else:
                    break
            except Exception as e:
                print(e)
                break

        try:
            # Add additional screenshots from Debian
            from bs4 import BeautifulSoup
            page = BeautifulSoup(urllib.request.urlopen(SCREENSHOT_DEBIAN_URL % self.pkginfo.name, timeout=5), "lxml")
            images = page.findAll('img')
            for image in images:
                if num_screenshots >= 4:
                    break
                if image['src'].startswith('/screenshots'):
                    num_screenshots += 1

                    thumb = THUMBNAIL_DEBIAN_URL % image['src']
                    link = thumb.replace("_small", "_large")

                    local_name = os.path.join(constants.SCREENSHOT_DIR, "%s_%s.png" % (self.pkginfo.name, num_screenshots))
                    self.save_to_file(link, None, local_name)

                    self.add_screenshot(self.pkginfo, local_name, num_screenshots)
        except Exception as e:
            pass


        if num_screenshots == 0:
            self.add_screenshot(self.pkginfo, None, 0)

    def save_to_file(self, url, source_url, path):
        r = requests.get(url, stream=True, timeout=10)

        with open(path, 'wb') as fd:
            for chunk in r.iter_content(chunk_size=128):
                fd.write(chunk)

        if source_url is None:
            source_url = path

        file = Gio.File.new_for_path(path)
        info = Gio.FileInfo.new()
        info.set_attribute_string(f"metadata::{constants.APP}-screenshot-source-url", source_url)
        try:
            file.set_attributes_from_info(info, Gio.FileQueryInfoFlags.NONE, None)
        except GLib.Error as e:
            print("Unable to store screenshot source url to metadata '%s': %s" % (source_url, e.message))

    def add_screenshot(self, pkginfo, name, num):
        GLib.idle_add(self.add_ss_idle, pkginfo, name, num)

    def add_ss_idle(self, pkginfo, name, num):
        self.application.add_screenshot(pkginfo, name, num)
