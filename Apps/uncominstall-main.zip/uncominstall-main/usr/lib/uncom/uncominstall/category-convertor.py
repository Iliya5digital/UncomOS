import os
import yaml
from pathlib import Path


def file_to_array(filename):
    array = []

    with open(filename) as f:
        for line in f:
            line = line.replace("\n", "").replace("\r", "").strip()
            if line != "":
                array.append(line)
    return array

if __name__ == "__main__":
    categories = {}
    srcAbsPath = os.path.abspath("../../../../usr/share/uncom/uncominstall/categories")
    with os.scandir(srcAbsPath) as it:
        for entry in it:
            if entry.path.endswith(".list"):
                category_name = os.path.splitext(entry.name)[0]
                category = {}
                category["list"] = file_to_array(entry.path)
                categories[category_name] = category
    path = Path( os.path.join(srcAbsPath, "categories.yaml"))
    root = {}
    root["categories"] = categories
    with path.open(mode='w', encoding="utf8") as f:
        yaml.dump(root, f)

