#!/usr/bin/python3
# -*- coding: utf-8 -*-

import aptdaemon.console
from aptdaemon.console import ConsoleClient
from gettext import gettext as _
from gi.repository import GLib
import os
from pathlib import Path


from mintcommon.installer import installer, cache

SYS_CACHE_PATH = "/var/cache/uncominstall/pkginfo.json"
USER_CACHE_PATH = os.path.join(GLib.get_user_cache_dir(), "uncominstall", "pkginfo.json")

def _get_best_save_path():
    best_path = None

    # Prefer the system location, as all users can access it
    try:
        path = Path(SYS_CACHE_PATH)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.touch(exist_ok=True)
    except PermissionError:
        try:
            path = Path(USER_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
    finally:
        best_path = path

    return best_path


if __name__ == "__main__":
    print("Running apt from console")
    con = ConsoleClient(show_terminal=True,
                        allow_unauthenticated=False,
                        details=True)
    con._progress_id = GLib.timeout_add(250, con._update_custom_progress,
                                        _("Waiting for authentication"))
    con.update_cache()
    con.run()

print("Removing old cache...")
cache_file = _get_best_save_path()
root = Path("/")
if (not cache_file.parts[1].startswith("var") and not cache_file.parts[1].startswith("home")) or (root.resolve() == cache_file.resolve()):
    print("Path error, going further")
else:
    print("Removing cache...")
    try:
        os.unlink(cache_file)
    except FileNotFoundError:
        print("Ignore FileNotFoundError")

print("Running cache update for uncominstall")
installer = installer.Installer()
pkgcache = cache.PkgCache(installer.have_flatpak)
try:
    installer.init_sync()
    installer.force_new_cache()
except Exception as e:
    print(e)

exit()
