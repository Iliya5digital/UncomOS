import os
from gi.repository import GLib


ADDON_ICON_SIZE = 24
FEATURED_ICON_SIZE = 64
LIST_ICON_SIZE = 64
DETAILS_ICON_SIZE = 64
SCREENSHOT_HEIGHT = 351
SCREENSHOT_WIDTH = 624

#Hardcoded mouse back button key for button-press-event
#May not work on all mice
MOUSE_BACK_BUTTON = 8

# Gsettings keys
SEARCH_IN_SUMMARY = "search-in-summary"
SEARCH_IN_DESCRIPTION = "search-in-description"
INSTALLED_APPS = "installed-apps"
SEARCH_IN_CATEGORY = "search-in-category"
HAMONIKR_SCREENSHOTS = "hamonikr-screenshots"

# package type combobox columns
# index, label, icon-name, tooltip, pkginfo
PACKAGE_TYPE_COMBO_INDEX = 0
PACKAGE_TYPE_COMBO_LABEL = 1
PACKAGE_TYPE_COMBO_SUMMARY = 2
PACKAGE_TYPE_COMBO_ICON_NAME = 3
PACKAGE_TYPE_COMBO_PKGINFO = 4

APP = 'uncominstall'
VERSION = "8.2.4-uncom32"
LOCALE_DIR = f"/usr/share/uncom/{APP}/locale"
FALLBACK_PACKAGE_ICON_PATH = f"/usr/share/uncom/{APP}/data/available.png"
SCREENSHOT_DIR = os.path.join(GLib.get_user_cache_dir(), APP, "screenshots")
FLATHUB_MEDIA_BASE_URL = "https://dl.flathub.org/media/"
BOTTLE_PACKAGE_NAME = "com.usebottles.bottles"
EXE_MIME_TYPE = "application/x-ms-dos-executable"

