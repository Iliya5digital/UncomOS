import os
from gi.repository import GLib


PATH_TO_KEY_FILE = "/usr/local/uncom-setup/files/.uncom_license"

def load_os_key():
    stored_license_key = None
    if os.path.isfile(PATH_TO_KEY_FILE):
        print("License file exists, checking it contents...")
        with open(PATH_TO_KEY_FILE, encoding="utf-8") as file:
            stored_license_key = file.read()
            file.close()
    return stored_license_key


KB = 1000
MB = KB * 1000

def get_size_for_display(size):
    if size == 0:
        return ""

    if size > (5 * MB):
        size = (size // MB) * MB
    elif size > KB:
        size = (size // KB) * KB

    formatted = GLib.format_size(size).replace(".0", "")
    return formatted
