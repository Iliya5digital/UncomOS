import gettext
import constants
from gi.repository import Gtk, Gio, GLib

_ = gettext.gettext

class VerticalPackageTile(Gtk.FlowBoxChild):
    def __init__(self, pkginfo, icon, installer, show_package_type=False, review_info=None):
        super(VerticalPackageTile, self).__init__()

        self.button = Gtk.Button();
        self.button.connect("clicked", self._activate_fb_child)
        self.button.set_can_focus(False)
        self.add(self.button)

        self.pkginfo = pkginfo
        self.installer = installer

        glade_file = f"/usr/share/uncom/{constants.APP}/vertical-tile.glade"
        self.builder = Gtk.Builder()
        self.builder.add_from_file(glade_file)

        self.overlay = self.builder.get_object("vertical_package_tile")
        self.button.add(self.overlay)

        self.icon_holder = self.builder.get_object("icon_holder")
        self.package_label = self.builder.get_object("package_label")
        self.package_summary = self.builder.get_object("package_summary")
        self.package_type_box = self.builder.get_object("package_type_box")
        self.package_type_emblem = self.builder.get_object("package_type_emblem")
        self.package_type_name = self.builder.get_object("package_type_name")
        self.installed_mark = self.builder.get_object("installed_mark")

        self.icon_holder.add(icon)

        display_name = self.installer.get_display_name(pkginfo)
        self.package_label.set_label(display_name)

        summary = self.installer.get_summary(pkginfo)
        self.package_summary.set_label(summary)

        if show_package_type:
            if pkginfo.pkg_hash.startswith("f"):

                remote_info = None

                try:
                    remote_info = self.installer.get_remote_info_for_name(pkginfo.remote)
                    if remote_info:
                        self.package_type_name.set_label(remote_info.title)
                except:
                    pass

                if remote_info is None:
                    self.package_type_name.set_label(pkginfo.remote.capitalize())

                self.package_type_box.set_tooltip_text(_("This package is a Flatpak"))
                self.package_type_emblem.set_from_icon_name("uncominstall-package-flatpak-symbolic", Gtk.IconSize.MENU)
            else:
                self.package_type_name.set_label(_("Package"))
                self.package_type_box.set_tooltip_text(_("This is a system package"))
                self.package_type_emblem.set_from_icon_name("uncom-logo-badge-symbolic", Gtk.IconSize.MENU)
            self.package_type_box.show()

        if review_info:
            self.fill_rating_widget(review_info)

        self.show_all()
        self.refresh_state()

    def _activate_fb_child(self, widget):
        self.activate()

    def refresh_state(self):
        self.installed = self.installer.pkginfo_is_installed(self.pkginfo)

        if self.installed:
            self.installed_mark.set_from_icon_name("emblem-installed", Gtk.IconSize.MENU)
        else:
            self.installed_mark.clear()

    def fill_rating_widget(self, review_info):
        review_info_box = self.builder.get_object("review_info_box")

        stars_box = self.builder.get_object("stars_box")

        rating = review_info.avg_rating
        remaining_stars = 5
        while rating >= 1.0:
            star = Gtk.Image(icon_name="starred-symbolic", pixel_size=12)
            stars_box.pack_start(star, False, False, 0)
            rating -= 1
            remaining_stars -= 1
        if rating > 0.0:
            star = Gtk.Image(icon_name="semi-starred-symbolic", pixel_size=12)
            stars_box.pack_start(star, False, False, 0)
            remaining_stars -= 1
        for i in range (remaining_stars):
            star = Gtk.Image(icon_name="non-starred-symbolic", pixel_size=12)
            stars_box.pack_start(star, False, False, 0)
        stars_box.show_all()

        num_reviews_label = self.builder.get_object("num_reviews_label")
        num_reviews_label.set_label(str(review_info.num_reviews))
