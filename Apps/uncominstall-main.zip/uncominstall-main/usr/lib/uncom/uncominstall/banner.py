import gi
gi.require_version('Gtk', '3.0')
gi.require_version('XApp', '1.0')
gi.require_version('AppStreamGlib', '1.0')
from gi.repository import Gtk, Gdk


class BannerButton(Gtk.Button):
    def __init__(self, title, summary, background, color, text_shadow, border_color):
        super(Gtk.Button, self).__init__()

        self.title = title
        self.summary = summary

        self.connect("realize", self.set_cursor)

        css = """
#FeatureTile
{
    background: %(background)s;
    color: %(color)s;
    text-shadow: %(text_shadow)s;
    border-color: %(border_color)s;
    padding: 4px;
    outline-color: alpha(%(color)s, 0.75);
    outline-style: dashed;
    outline-offset: 2px;
}

#FeatureTitle {
    color: %(color)s;
    text-shadow: %(text_shadow)s;
    font-weight: bold;
    font-size: 24px;
}

#FeatureSummary {
    color: %(color)s;
    text-shadow: %(text_shadow)s;
    font-weight: bold;
    font-size: 12px;
}
""" % {'background':background, 'color':color, 'text_shadow':text_shadow, 'border_color':border_color}

        self.set_name("FeatureTile")
        style_provider = Gtk.CssProvider()
        style_provider.load_from_data(str.encode(css))
        Gtk.StyleContext.add_provider_for_screen(Gdk.Screen.get_default(),
                                                 style_provider,
                                                 Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

        label_name = Gtk.Label(xalign=1.0)
        label_name.set_label(self.title)
        label_name.set_name("FeatureTitle")

        label_summary = Gtk.Label(xalign=1.0)
        label_summary.set_label(self.summary)
        label_summary.set_name("FeatureSummary")

        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4, halign=Gtk.Align.END)
        vbox.set_border_width(6)

        vbox.pack_end(label_summary, False, False, 0)
        vbox.pack_end(label_name, False, False, 0)

        hbox = Gtk.Box()
        hbox.pack_end(vbox, True, True, 0)

        self.add(hbox)

    def set_cursor(self, widget, data=None):
        hand = Gdk.Cursor.new_from_name(Gdk.Display.get_default(), "pointer")
        self.get_window().set_cursor(hand)
