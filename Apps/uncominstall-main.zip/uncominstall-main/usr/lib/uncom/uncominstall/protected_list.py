import os
import threading
import json
import urllib

import yaml
import requests
import multiprocessing
from pathlib import Path
from gi.repository import GLib, GObject

from misc import print_timing


class ProtectedListCache(object):
    def __init__(self, packages: list, size: int):
        super(ProtectedListCache, self).__init__()

        self.packages = packages
        self.size = int(size)

    @classmethod
    def empty(cls):
        return cls([], 0)


    @classmethod
    def from_yaml(cls, yaml_data: dict, size: int):
        return cls(yaml_data["packages"], size)

    @classmethod
    def from_json(cls, json_data: dict):
        cache_data = json_data["packages"]
        return cls(cache_data, json_data["size"])


class ProtectedList(GObject.Object):
    CACHE_DIR = os.path.join(GLib.get_user_cache_dir(), "uncominstall")
    CONFIG_CACHE_NAME = "protected_list.json"
    CONFIG_CACHE_PATH = os.path.join(CACHE_DIR, CONFIG_CACHE_NAME)
    LOCAL_DIR = "/usr/share/uncom/uncominstall/"
    SERVER_URL = "https://download.uncom.tech/uncom-install/"
    CONFIG_SERVER_NAME = "protected_list.yaml"
    CONFIG_SERVER_URL = urllib.parse.urljoin(SERVER_URL, CONFIG_SERVER_NAME)

    __gsignals__ = {
        'protected-list-initialized': (GObject.SignalFlags.RUN_LAST, None, (bool,)),
    }

    @print_timing
    def __init__(self):
        GObject.Object.__init__(self)

        self._cache_lock = threading.Lock()

        self._cache = self._load_cache()
        if len(self) == 0:
            self._cache = self._restore_default_list()

        self.proc = None

        self._update_cache()

    def is_process(self):
        return self.proc is not None

    def kill(self):
        try:
            self.proc.terminate()
            self.proc = None
        except AttributeError as e:
            pass

    def values(self):
        with self._cache_lock:
            return self._cache.packages

    def __getitem__(self, key: int):
        with self._cache_lock:
            try:
                return self._cache.packages[key]
            except KeyError:
                return {}

    def __contains__(self, name):
        with self._cache_lock:
            return name in self._cache.packages

    def __len__(self):
        with self._cache_lock:
            return len(self._cache.packages)

    def has_protected(self, items: list):
        with self._cache_lock:
            for item in items:
                if item in self._cache.packages:
                    return True
            return False

    def is_package_protected(self, package: str):
        with self._cache_lock:
            if package in self._cache.packages:
                return True
        return False

    def get_protected_items(self, items: list):
        with self._cache_lock:
            return [item for item in items if item in self._cache.packages]

    def _load_cache(self):
        cache = ProtectedListCache.empty()

        path = None

        try:
            path = Path(self.CONFIG_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            if path is not None:
                try:
                    with path.open(mode='r', encoding="utf8") as f:
                        cache = ProtectedListCache.from_json(json.load(f))
                except Exception as e:
                    print("UncomInstall: Cannot open protected list cache. File path: %s" % self.CONFIG_CACHE_PATH)
        return cache

    def _save_cache(self, cache: ProtectedListCache):
        path = {}

        try:
            path = Path(self.CONFIG_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            try:
                with path.open(mode='w', encoding="utf8") as f:
                    json.dump(cache, f, default=lambda o: o.__dict__, indent=4)
            except Exception as e:
                print("UncomInstall: Could not save protected list cache. File path: %s" % self.CONFIG_CACHE_PATH)

    def _update_cache(self):
        thread = threading.Thread(target=self._update_list_thread)
        thread.start()

    @print_timing
    def _update_list_thread(self):

        success = multiprocessing.Value('b', False)

        current_size = multiprocessing.Value('d', self._cache.size)
        self.proc = multiprocessing.Process(target=self._update_cache_process, args=(success, current_size))
        self.proc.start()

        self.proc.join()

        self.proc = None

        if success.value:
            with self._cache_lock:
                self._cache = self._load_cache()
        GLib.idle_add(self.emit_list_updated, success.value)

    def emit_list_updated(self, success: bool):
        self.emit("protected-list-initialized", success)

    def _update_cache_process(self, success: bool, current_size: int):
        cache, result = self._download_list(current_size)
        if not result:
            success.value = False
            return
        self._save_cache(cache)
        success.value = True

    def _download_list(self, current_size: int):
        cache = ProtectedListCache.empty()
        result = False
        try:
            r = requests.head(self.CONFIG_SERVER_URL, timeout=2)
            size = int(r.headers.get("Content-Length"))
            if r.status_code == 200:
                if size != current_size.value:
                    r = requests.get(self.CONFIG_SERVER_URL, timeout=30)
                    yaml_data = yaml.safe_load(r.text)
                    cache = ProtectedListCache.from_yaml(yaml_data, size)
                    print("UncomInstall: Downloaded new protected list")
                    result = True
                else:
                    print("UncomInstall: No new protected list")
            else:
                print("UncomInstall: Could not download updated protected list: %s" % r.reason)
        except Exception as e:
            print("UncomInstall: Problem attempting to access protected list url: %s" % self.CONFIG_SERVER_URL)
        return cache, result

    def _restore_default_list(self):
        cache, result = self._load_local_list()
        if not result:
            return cache
        self._save_cache(cache)
        return cache

    def _load_local_list(self):
        cache = ProtectedListCache.empty()
        result = False
        file_path = os.path.join(self.LOCAL_DIR, self.CONFIG_SERVER_NAME)
        try:
            size = os.path.getsize(file_path)
            with open(file_path, 'r', encoding="utf-8") as file:
                yaml_data = yaml.safe_load(file)
                cache = ProtectedListCache.from_yaml(yaml_data, size)
                print("UncomInstall: Load default protected list")
                result = True
        except Exception as e:
            print("UncomInstall: Problem attempting to access default protected list : %s" % file_path)
        return cache, result

