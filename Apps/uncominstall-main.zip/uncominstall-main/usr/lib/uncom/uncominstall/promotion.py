import gi
import os
import gettext
import subprocess
import utils

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk

_ = gettext.gettext

class PromotionDialog(Gtk.Window):

    GLADE_FILE_PATH = f"/usr/share/uncom/uncominstall/promotion.glade"


    def __init__(self, uri,  parent):
        Gtk.Window.__init__(self, title=_("Promotional Dialog"), transient_for=parent, modal=True)

        self.uri = uri
        self.builder = Gtk.Builder()
        self.builder.set_translation_domain("uncominstall")
        self.builder.add_from_file(self.GLADE_FILE_PATH)
        self.builder.connect_signals(self)
        self.add(self.builder.get_object("Content"))
        self.promotion_key = self.load_promo_key()
        if(self.promotion_key is None):
            self.promotion_key = "XXXXX"
        self.builder.get_object("PromoCode").set_text(self.promotion_key)
        self.builder.get_object("BuyButton").connect("clicked", self.on_promo_code_clicked)
        self.builder.get_object("CopyButton").connect("clicked", self.on_promo_code_copy)

    def load_promo_key(self):
        key = utils.load_os_key()
        promo_key = None
        if key is None or key == "":
            return promo_key
        key_parts = key.split("-")
        if len(key_parts) == 5:
            promo_key = key_parts[4].upper()
        return promo_key

    def on_promo_code_clicked(self, widget):
        try:
            subprocess.Popen(["xdg-open", self.uri])
        except Exception as ex:
            print(f"An unexpected error occurred: {ex}")
        self.destroy()

    def on_promo_code_copy(self, widget):
        clipboard = Gtk.Clipboard.get(Gdk.SELECTION_CLIPBOARD)
        clipboard.set_text(self.promotion_key, -1)


