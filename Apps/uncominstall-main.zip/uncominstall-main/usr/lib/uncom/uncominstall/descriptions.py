import os
import threading
import json
import urllib

import yaml
import requests
import multiprocessing
from pathlib import Path
from gi.repository import GLib, GObject

from misc import print_timing


class Description(object):
    DEFAULT_LANG = "C"

    def __init__(self, name: dict, summary: dict = None, description: dict = None, icon: dict = None):
        self.name = name
        self.summary = summary
        self.description = description
        self.icon = None
        if icon is not None:
            self.icon = {}
            for key in icon.keys():
                size = int(key)
                self.icon[size] = icon[key]

    @classmethod
    def empty(cls):
        return cls({}, None, None, None)

    @classmethod
    def from_json(cls, json_data: dict):
        return cls(**json_data)

    @classmethod
    def from_yaml(cls, json_data: dict):
        return cls(**json_data)

    def get_translate_text(self, dictionary: dict, lang: str):
        if dictionary is None:
            return None
        name = dictionary.get(lang)
        if name is not None and len(name) != 0:
            return name
        name = dictionary.get(self.DEFAULT_LANG)
        if name is not None and len(name) != 0:
            return name
        if len(dictionary) == 0:
            return None
        names = list(dictionary.values())
        name = names[0]
        if name is None or len(name) != 0:
            return name
        return None

    def get_name(self, lang: str):
        return self.get_translate_text(self.name, lang)

    def get_summary(self, lang: str):
        return self.get_translate_text(self.summary, lang)

    def get_description(self, lang: str):
        return self.get_translate_text(self.description, lang)

    def get_icon_name(self, size: int):
        return self.icon.get(size)


class DescriptionsCache(object):
    def __init__(self, descriptions: dict, size: int):
        super(DescriptionsCache, self).__init__()

        self.descriptions = descriptions
        self.size = int(size)

    @classmethod
    def empty(cls):
        return cls({}, 0)

    @classmethod
    def from_json(cls, json_data: dict):
        new_dict = {}
        cache_data = json_data["descriptions"]
        for key in cache_data.keys():
            description_data = cache_data[key]
            new_dict[key] = Description.from_json(description_data)

        return cls(new_dict, json_data["size"])

    @classmethod
    def from_yaml(cls, yaml_data: dict, size: int):
        new_dict = {}
        cache_data = yaml_data["descriptions"]
        for key in cache_data.keys():
            description_data = cache_data[key]
            new_dict[key] = Description.from_yaml(description_data)
        return cls(new_dict, size)

    def get_icons(self):
        icons = {}
        for description in self.descriptions.values():
            icon = description.icon
            if icon is None or len(icon) == 0:
                continue
            for size in icon.keys():
                icon_name = icon[size]
                if icon_name is None or len(icon_name) == 0:
                    continue
                names = icons.get(size)
                if names is None:
                    names = []
                names.append(icon_name)
                icons[size] = names
        return icons


class Descriptions(GObject.Object):
    CACHE_DIR = os.path.join(GLib.get_user_cache_dir(), "uncominstall", "descriptions")
    ICONS_CACHE_DIR = os.path.join(CACHE_DIR, "icons")
    CONFIG_CACHE_NAME = "descriptions.json"
    CONFIG_CACHE_PATH = os.path.join(CACHE_DIR, CONFIG_CACHE_NAME)
    LOCAL_DIR = "/usr/share/uncom/uncominstall/descriptions/"
    LOCAL_ICONS_DIR = os.path.join(LOCAL_DIR, "icons")
    SERVER_URL = "https://download.uncom.tech/uncom-install/descriptions/"
    ICONS_SERVER_URL = urllib.parse.urljoin(SERVER_URL, "icons/")
    CONFIG_SERVER_NAME = "descriptions.yaml"
    CONFIG_SERVER_URL = urllib.parse.urljoin(SERVER_URL, CONFIG_SERVER_NAME)
    ICON_EXTENSION = ".png"

    __gsignals__ = {
        'descriptions-initialized': (GObject.SignalFlags.RUN_LAST, None, (bool,)),
    }

    @print_timing
    def __init__(self):
        GObject.Object.__init__(self)

        self._cache_lock = threading.Lock()

        self._cache = self._load_cache()
        if len(self) == 0:
            self._cache = self._restore_default_descriptions()

        self.proc = None

        self._update_cache()

    def is_process(self):
        return self.proc is not None

    def kill(self):
        try:
            self.proc.terminate()
            self.proc = None
        except AttributeError as e:
            pass

    def keys(self):
        with self._cache_lock:
            return self._cache.descriptions.keys()

    def values(self):
        with self._cache_lock:
            return self._cache.descriptions.values()

    def __getitem__(self, key):
        with self._cache_lock:
            try:
                return self._cache.descriptions[key]
            except KeyError:
                return Description(key)

    def __contains__(self, name):
        with self._cache_lock:
            return name in self._cache.descriptions

    def __len__(self):
        with self._cache_lock:
            return len(self._cache.descriptions)

    def _load_cache(self):
        cache = DescriptionsCache.empty()

        path = None

        try:
            path = Path(self.CONFIG_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            if path is not None:
                try:
                    with path.open(mode='r', encoding="utf8") as f:
                        cache = DescriptionsCache.from_json(json.load(f))
                except Exception as e:
                    print("UncomInstall: Cannot open description cache. File path: %s" % self.CONFIG_CACHE_PATH)
        return cache

    def _save_cache(self, cache: DescriptionsCache):
        path = {}

        try:
            path = Path(self.CONFIG_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            try:
                with path.open(mode='w', encoding="utf8") as f:
                    json.dump(cache, f, default=lambda o: o.__dict__, indent=4)
            except Exception as e:
                print("UncomInstall: Could not save descriptions cache. File path: %s" % self.CONFIG_CACHE_PATH)

    def _update_cache(self):
        thread = threading.Thread(target=self._update_descriptions_thread)
        thread.start()

    @print_timing
    def _update_descriptions_thread(self):

        success = multiprocessing.Value('b', False)

        current_size = multiprocessing.Value('d', self._cache.size)
        self.proc = multiprocessing.Process(target=self._update_cache_process, args=(success, current_size))
        self.proc.start()

        self.proc.join()

        self.proc = None

        if success.value:
            with self._cache_lock:
                self._cache = self._load_cache()
        GLib.idle_add(self.emit_descriptions_updated, success.value)

    def emit_descriptions_updated(self, success: bool):
        self.emit("descriptions-initialized", success)

    def _update_cache_process(self, success: bool, current_size: int):
        cache, result = self._download_descriptions(current_size)
        if not result:
            success.value = False
            return
        icon_names = cache.get_icons()
        self._download_icons(icon_names)
        self._save_cache(cache)
        success.value = True

    def _download_descriptions(self, current_size: int):
        cache = DescriptionsCache.empty()
        result = False
        try:
            r = requests.head(self.CONFIG_SERVER_URL, timeout=2)
            size = int(r.headers.get("Content-Length"))
            if r.status_code == 200:
                if size != current_size.value:
                    r = requests.get(self.CONFIG_SERVER_URL, timeout=30)
                    yaml_data = yaml.safe_load(r.text)
                    cache = DescriptionsCache.from_yaml(yaml_data, size)
                    print("UncomInstall: Downloaded new descriptions")
                    result = True
                else:
                    print("UncomInstall: No new descriptions")
            else:
                print("UncomInstall: Could not download updated descriptions: %s" % r.reason)
        except Exception as e:
            print("UncomInstall: Problem attempting to access descriptions url: %s" % self.CONFIG_SERVER_URL)
        return cache, result

    def _download_icons(self, icons: dict):
        for size in icons.keys():
            size_path = os.path.join(self.ICONS_CACHE_DIR, str(size))
            size_url = urllib.parse.urljoin(self.ICONS_SERVER_URL, str(size))
            if not os.path.exists(size_path):
                os.makedirs(size_path)
            icon_names = icons[size]
            for icon_name in icon_names:
                icon_file_name = icon_name + self.ICON_EXTENSION
                icon_path = os.path.join(size_path, icon_file_name)
                icon_url = urllib.parse.urljoin(size_url, icon_file_name)
                result = self._download_icon(icon_url, icon_path)
                attempts = 0
                while not result and attempts < 3:
                    result = self._download_icon(icon_url, icon_path)
                    attempts += 1

    def _download_icon(self, icon_url: str, icon_path: str):
        try:
            icon_size = 0
            if os.path.isfile(icon_path):
                icon_size = os.path.getsize(icon_path)
            r = requests.head(icon_url, timeout=2)
            size = int(r.headers.get("Content-Length"))
            if r.status_code == 200:
                if size != icon_size:
                    r = requests.get(icon_url, stream=True, timeout=20)
                    with open(icon_path, 'wb') as fd:
                        for chunk in r.iter_content(chunk_size=128):
                            fd.write(chunk)
                else:
                    print("UncomInstall: No new icon")
                return True
        except Exception as e:
            print("UncomInstall: Problem attempting to access icon url: %s" % icon_url)
        return False

    def _restore_default_descriptions(self):
        cache, result = self._load_local_descriptions()
        if not result:
            return cache
        icon_names = cache.get_icons()
        self._copy_local_icons(icon_names)
        self._save_cache(cache)
        return cache

    def _load_local_descriptions(self):
        cache = DescriptionsCache.empty()
        result = False
        file_path = os.path.join(self.LOCAL_DIR, self.CONFIG_SERVER_NAME)
        try:
            size = os.path.getsize(file_path)
            with open(file_path, 'r', encoding="utf-8") as file:
                yaml_data = yaml.safe_load(file)
                cache = DescriptionsCache.from_yaml(yaml_data, size)
                print("UncomInstall: Load default descriptions")
                result = True
        except Exception as e:
            print("UncomInstall: Problem attempting to access default descriptions : %s" % file_path)
        return cache, result

    def _copy_local_icons(self, icons: dict):
        for size in icons.keys():
            size_src_path = os.path.join(self.LOCAL_ICONS_DIR, str(size))
            size_dst_path = os.path.join(self.ICONS_CACHE_DIR, str(size))
            if not os.path.exists(size_dst_path):
                os.makedirs(size_dst_path)
            icon_names = icons[size]
            for icon_name in icon_names:
                icon_file_name = icon_name + self.ICON_EXTENSION
                icon_src_path = os.path.join(size_src_path, icon_file_name)
                icon_dst_path = os.path.join(size_dst_path, icon_file_name)
                if os.path.isfile(icon_src_path):
                    if not os.path.exists(icon_dst_path):
                        with open(icon_src_path, 'rb') as source_file, open(icon_dst_path, 'wb') as destination_file:
                            destination_file.write(source_file.read())

    def get_icon_path(self, package_name: str, size: int):
        description = self[package_name]
        if description is None or description.icon is None or len(description.icon) == 0:
            return None
        icon_name = description.get_icon_name(size)
        if icon_name is None or len(icon_name) == 0:
            return None
        size_path = os.path.join(self.ICONS_CACHE_DIR, str(size))
        icon_file_name = icon_name + self.ICON_EXTENSION
        icon_path = os.path.join(size_path, icon_file_name)
        if not os.path.isfile(icon_path):
            return None
        return icon_path
