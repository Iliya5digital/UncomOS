import gettext
import gi
import constants
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib

GLADE_FILE = f"/usr/share/uncom/{constants.APP}/package-row.glade"

class PackageRow(Gtk.ListBoxRow):
    def __init__(self, pkginfo, icon, summary, installer, from_search=False, review_info=None):
        super(Gtk.ListBoxRow, self).__init__()
        self.pkginfo = pkginfo
        self.installed_mark = Gtk.Image()
        self.installer = installer
        self.asapp = self.installer.get_appstream_app_for_pkginfo(pkginfo)

        self.builder = Gtk.Builder()
        self.builder.add_from_file(GLADE_FILE)

        self.main_box = self.builder.get_object("package_row")
        self.add(self.main_box)
        self.main_box.connect("button-press-event", lambda w, e: Gdk.EVENT_PROPAGATE)
        self.main_box.connect("button-release-event", lambda w, e: Gdk.EVENT_PROPAGATE)

        self.app_icon_holder = self.builder.get_object("app_icon_holder")
        self.app_display_name = self.builder.get_object("app_display_name")
        self.app_summary = self.builder.get_object("app_summary")
        self.flatpak_badge = self.builder.get_object("flatpak_badge")
        self.category_label = self.builder.get_object("category_label")
        self.installed_mark = self.builder.get_object("installed_mark")

        self.app_icon_holder.add(icon)

        display_name = self.installer.get_display_name(pkginfo)
        display_name = GLib.markup_escape_text(display_name)

        if pkginfo.pkg_hash.startswith("f"):
            self.flatpak_badge.show()
        else:
            self.flatpak_badge.hide()

        self.app_display_name.set_label(display_name)
        self.app_summary.set_label(summary)
        self.show_all()

        if review_info:
            self.fill_rating_widget(review_info)

        self.refresh_state()

    def refresh_state(self):
        self.installed = self.installer.pkginfo_is_installed(self.pkginfo)

        if self.installed:
            self.installed_mark.set_from_icon_name("emblem-ok-symbolic", Gtk.IconSize.LARGE_TOOLBAR)
        else:
            self.installed_mark.clear()

    def fill_rating_widget(self, review_info):
        review_info_box = self.builder.get_object("review_info_box")

        stars_box = self.builder.get_object("stars_box")

        rating = review_info.avg_rating
        remaining_stars = 5
        while rating >= 1.0:
            stars_box.pack_start(Gtk.Image.new_from_icon_name("starred-symbolic", Gtk.IconSize.MENU), False, False, 0)
            rating -= 1
            remaining_stars -= 1
        if rating > 0.0:
            stars_box.pack_start(Gtk.Image.new_from_icon_name("semi-starred-symbolic", Gtk.IconSize.MENU), False, False, 0)
            remaining_stars -= 1
        for i in range (remaining_stars):
            stars_box.pack_start(Gtk.Image.new_from_icon_name("non-starred-symbolic", Gtk.IconSize.MENU), False, False, 0)
        stars_box.show_all()

        num_reviews_label = self.builder.get_object("num_reviews_label")

        # TRANSLATORS: showing specific number of reviews in the list view and the header of the package details.
        review_text = gettext.ngettext("%d Review", "%d Reviews", review_info.num_reviews) % review_info.num_reviews
        num_reviews_label.set_label(review_text)
