import os
import threading
import json
import yaml
import requests
import multiprocessing
from pathlib import Path
from gi.repository import GLib, GObject

from misc import print_timing
from enum import Enum

class FeaturedItem(object):
    def __init__(self, packagename, background, border_color, text_color, text_shadow, uri, tag):
        self.packagename = packagename
        self.background = background
        self.border_color = border_color
        self.text_color = text_color
        self.text_shadow = text_shadow
        self.uri = uri
        self.tag = tag

    @classmethod
    def empty(cls):
        return cls("", "", "", "", "", "", "")

    @classmethod
    def from_json(cls, json_data: dict):
        return cls(**json_data)

    @classmethod
    def from_yaml(cls, json_data: dict):
        return cls(**json_data)

    def is_uri(self):
        return self.uri is not None and len(self.uri) > 0

class FeaturedListCache(object):
    def __init__(self, list: dict, size: int):
        super(FeaturedListCache, self).__init__()

        self.list = list
        self.size = int(size)

    @classmethod
    def empty(cls):
        return cls({}, 0)

    @classmethod
    def from_json(cls, json_data: dict):
        new_dict = {}
        cache_data = json_data["list"]
        for key in cache_data.keys():
            info_data = cache_data[key]
            new_dict[key] = FeaturedItem.from_json(info_data)

        return cls(new_dict, json_data["size"])

    @classmethod
    def from_yaml(cls, yaml_data: dict, size: int):
        new_dict = {}
        cache_data = yaml_data["list"]
        for key in cache_data.keys():
            info_data = cache_data[key]
            new_dict[key] = FeaturedItem.from_yaml(info_data)

        return cls(new_dict, size)

class FeaturedList(GObject.Object):
    FEATURED_LIST_PATH = os.path.join(GLib.get_user_cache_dir(), "uncominstall", "featured")
    FEATURED_LIST_CACHE = os.path.join(FEATURED_LIST_PATH, "featured_list.json")
    FEATURED_LIST_DEFAULT_PATH = "/usr/share/uncom/uncominstall/featured/"
    FEATURED_LIST_DEFAULT = os.path.join(FEATURED_LIST_DEFAULT_PATH, "featured.yaml")
    FEATURED_LIST_URL = "https://download.uncom.tech/uncom-install/featured/featured.yaml"
    FEATURED_IMAGE_URL = "https://download.uncom.tech/uncom-install/featured/%s"
    IMAGE_PREFIX = "@prefix@"

    __gsignals__ = {
        'featured-list-updated': (GObject.SignalFlags.RUN_LAST, None, (bool,)),
    }
    @print_timing
    def __init__(self):
        GObject.Object.__init__(self)

        self._cache_lock = threading.Lock()

        self._cache = self._load_cache()
        if len(self) == 0:
            self._cache = self._restore_default_feature_list()

        self.proc = None

        self._update_cache()

    def is_process(self):
        return self.proc is not None

    def kill(self):
        try:
            self.proc.terminate()
            self.proc = None
        except AttributeError as e:
            pass

    def keys(self):
        with self._cache_lock:
            return self._cache.list.keys()

    def values(self):
        with self._cache_lock:
            return self._cache.list.values()

    def __getitem__(self, key):
        with self._cache_lock:
            try:
                return self._cache.list[key]
            except KeyError:
                return FeaturedItem.empty()

    def __contains__(self, name):
        with self._cache_lock:
            return name in self._cache.list

    def __len__(self):
        with self._cache_lock:
            return len(self._cache.list)

    def _load_cache(self):
        cache = FeaturedListCache.empty()

        path = None

        try:
            path = Path(self.FEATURED_LIST_CACHE)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            if path is not None:
                try:
                    with path.open(mode='r', encoding="utf8") as f:
                        cache = FeaturedListCache.from_json(json.load(f))
                except Exception as e:
                    print("UncomInstall: Cannot open featured list cache. File path: %s" % self.FEATURED_LIST_CACHE)
        return cache

    def _save_cache(self, cache: FeaturedListCache):
        path = {}
        try:
            path = Path(self.FEATURED_LIST_CACHE)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            try:
                with path.open(mode='w', encoding="utf8") as f:
                    json.dump(cache, f, default=lambda o: o.__dict__, indent=4)
            except Exception as e:
                print("UncomInstall: Could not save featured list cache. File path: %s" % self.FEATURED_LIST_CACHE)

    def _update_cache(self):
        thread = threading.Thread(target=self._update_featured_list_thread)
        thread.start()

    @print_timing
    def _update_featured_list_thread(self):

        success = multiprocessing.Value('b', False)

        current_size = multiprocessing.Value('d', self._cache.size)
        self.proc = multiprocessing.Process(target=self._update_cache_process, args=(success, current_size))
        self.proc.start()

        self.proc.join()

        self.proc = None

        if success.value:
            with self._cache_lock:
                self._cache = self._load_cache()
        GLib.idle_add(self.emit_featured_list_updated, success.value)

    def emit_featured_list_updated(self, success: bool):
        self.emit("featured-list-updated", success)

    def _update_cache_process(self, success, current_size):
        cache, result = self._download_feature_list(current_size)
        if not result:
            success.value = False
            return
        image_names = self._update_image_names(cache)
        self._save_cache(cache)
        self._download_images(image_names)
        success.value = True

    def _download_feature_list(self, current_size):
        cache = FeaturedListCache.empty()
        result = False
        try:
            r = requests.head(self.FEATURED_LIST_URL, timeout=2)
            size = int(r.headers.get("Content-Length"))
            if r.status_code == 200:
                if size != current_size.value:
                    r = requests.get(self.FEATURED_LIST_URL, timeout=30)
                    yaml_data = yaml.safe_load(r.text)
                    cache = FeaturedListCache.from_yaml(yaml_data, size)
                    print("UncomInstall: Downloaded new featured list")
                    result = True
                else:
                    print("UncomInstall: No new featured list")
            else:
                print("UncomInstall: Could not download updated featured list: %s" % r.reason)
        except Exception as e:
            print("UncomInstall: Problem attempting to access featured list url: %s" % self.FEATURED_LIST_URL)
        return cache, result

    def _download_images(self, image_names):
        for image_name in image_names:
            image_path = os.path.join(self.FEATURED_LIST_PATH, image_name)
            if os.path.isfile(image_path):
                continue
            result = self._download_image(self.FEATURED_IMAGE_URL % image_name, image_path)
            attempts = 0
            while not result and attempts < 3:
                result = self._download_image(self.FEATURED_IMAGE_URL % image_name, image_path)
                attempts += 1

    def _download_image(self, image_url, image_path):
        try:
            r = requests.get(image_url, stream=True, timeout=20)

            with open(image_path, 'wb') as fd:
                for chunk in r.iter_content(chunk_size=128):
                    fd.write(chunk)
            return True
        except Exception as e:
            print("UncomInstall: Problem attempting to access image url: %s" % image_url)
            return False

    def _update_image_names(self, cache: FeaturedListCache):
        all_image_names = []
        for featured_item in cache.list.values():
            image_names = self._extract_image_names(featured_item.background)
            all_image_names.extend(image_names)
            featured_item.background = featured_item.background.replace(self.IMAGE_PREFIX, self.FEATURED_LIST_PATH+"/")
        return all_image_names

    def _extract_image_names(self, text):
        image_names = []
        start_index = 0
        while True:
            start_index = text.find(self.IMAGE_PREFIX, start_index)
            if start_index<0:
                break
            start_index = start_index + len(self.IMAGE_PREFIX)

            end_index = text.find("'", start_index)
            if end_index < 0:
                break

            if end_index > start_index >= len(self.IMAGE_PREFIX):
                image_name = text[start_index:end_index]
                image_names.append(image_name)
            start_index = end_index + 1
        return image_names

    def _restore_default_feature_list(self):
        cache, result = self._load_default_feature_list()
        if not result:
            return {}, 0
        image_names = self._update_image_names(cache)
        self._copy_default_images(image_names)
        self._save_cache(cache)
        return cache

    def _load_default_feature_list(self):
        cache = FeaturedListCache.empty()
        result = False
        file_path = self.FEATURED_LIST_DEFAULT
        try:
            size = os.path.getsize(file_path)
            with open(file_path, 'r', encoding="utf-8") as file:
                yaml_data = yaml.safe_load(file)
                cache = FeaturedListCache.from_yaml(yaml_data, size)
                print("UncomInstall: Load default featured list")
                result = True
        except Exception as e:
            print("UncomInstall: Problem attempting to access default featured list : %s" % file_path)
            new_featured_list = {}
            size = 0
        return cache, result

    def _copy_default_images(self, image_names):
        for file_name in image_names:
            source_path = os.path.join(self.FEATURED_LIST_DEFAULT_PATH, file_name)
            destination_path = os.path.join(self.FEATURED_LIST_PATH, file_name)

            if os.path.isfile(source_path):
                if not os.path.exists(destination_path):
                    with open(source_path, 'rb') as source_file, open(destination_path, 'wb') as destination_file:
                        destination_file.write(source_file.read())