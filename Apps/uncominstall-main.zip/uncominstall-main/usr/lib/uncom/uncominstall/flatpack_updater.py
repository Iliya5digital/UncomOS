import gi
import gettext
import constants

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib

_ = gettext.gettext

class FlatpackUpdaterDialog(Gtk.Window):

    GLADE_FILE_PATH = f"/usr/share/uncom/{constants.APP}/pack-update.glade"
    PACKAGE_LIST_PAGE = "Packages"
    WAITING_PAGE = "Waiting"

    def __init__(self, installer,  parent):
        Gtk.Window.__init__(self, title=_("Flatpack Updater Dialog"), transient_for=parent, modal=True)

        self.installer = installer
        self.builder = Gtk.Builder()
        self.builder.set_translation_domain("uncominstall")
        self.builder.add_from_file(self.GLADE_FILE_PATH)
        self.builder.connect_signals(self)
        self.add(self.builder.get_object("Content"))

        self.pages = self.builder.get_object("Pages")

        self.packages = self.builder.get_object(self.PACKAGE_LIST_PAGE)
        self.waiting = self.builder.get_object(self.WAITING_PAGE)
        self.pages.set_visible_child_name(self.WAITING_PAGE)
        self.installer.select_flatpak_updates([], self.on_all_flatpak_update_finished, None, None, None, True)

    def on_all_flatpak_update_finished(self, task):
        print(f"Download size: {task.download_size}")
        self.packageViews = {}
        flatpaks = list(task.to_update)
        self.flatpaks_to_update = []
        self.installer.cancel_task(task)
        for flatpak in flatpaks:
            if flatpak.get_branch() != "stable":
                continue
            if flatpak.get_name().endswith(".Locale"):
                continue
            pckinfo = self.installer.cache.find_pkginfo(flatpak.get_name(), 'f')
            packageView = FlatpackUpdaterView(pckinfo, flatpak, self.installer)
            self.packages.pack_start(packageView, True, True, 0)
            self.packageViews[flatpak.get_name()] = packageView
            self.flatpaks_to_update.append(flatpak)
            print(
                f"Flatpak '{flatpak.get_name()}' Kind '{flatpak.get_kind().value_nick}' Arc '{flatpak.get_arch()}' Branch '{flatpak.get_branch()}'")
        self.packages.show_all()
        self.flatpaks_index = 0
        self.installer.select_flatpak_updates([self.flatpaks_to_update[self.flatpaks_index].format_ref()], self.on_flatpak_update_finished, None, None, None, True)
        self.pages.set_visible_child_name(self.PACKAGE_LIST_PAGE)

    def on_flatpak_update_finished(self, task):
        flatpak = task.to_update[-1]
        packageView = self.packageViews.get(flatpak.get_name())
        if packageView is not None:
            packageView.set_package_description(f"Download size: {task.download_size}")
        print(f"Flatpak '{flatpak.get_name()}' download size: {task.download_size}")
        for flatpak in task.to_update:
            print(
                f"to update Flatpak '{flatpak.get_name()}' Kind '{flatpak.get_kind().value_nick}' Arc '{flatpak.get_arch()}' Branch '{flatpak.get_branch()}'")
        self.installer.cancel_task(task)
        self.flatpaks_index = self.flatpaks_index + 1
        if self.flatpaks_index < len(self.flatpaks_to_update):
            self.installer.select_flatpak_updates([self.flatpaks_to_update[self.flatpaks_index].format_ref()], self.on_flatpak_update_finished, None, None, None, True)



class FlatpackUpdaterView(Gtk.ListBoxRow):
    GLADE_FILE_PATH = f"/usr/share/uncom/{constants.APP}/pack-update-item.glade"

    def __init__(self, pkginfo, flatpack, installer):
        super(Gtk.ListBoxRow, self).__init__()
        self.pkginfo = pkginfo
        self.flatpack = flatpack
        self.installer = installer

        self.builder = Gtk.Builder()
        self.builder.add_from_file(self.GLADE_FILE_PATH)

        self.package = self.builder.get_object("Package")
        self.add(self.package)

        self.package_name = self.builder.get_object("PackageName")
        self.package_desc = self.builder.get_object("PackageDesc")
        self.update_button = self.builder.get_object("UpdateButton")
        self.update_button.connect("clicked", self.on_update_clicked)

        display_name = self.installer.get_display_name(pkginfo)
        display_name = GLib.markup_escape_text(display_name)
        self.package_name.set_label(display_name)
        self.show_all()

    def set_package_description(self, description):
        self.package_desc.set_label(description)

    def on_update_clicked(self, widget):
        self.installer.select_flatpak_updates([self.flatpack.format_ref()], self.on_installer_info_ready,
                                              self.on_installer_info_error, self.on_installer_finished,
                                              self.on_installer_progress, True)

    def on_installer_info_ready(self, task):
        print(f"Flatpak '{self.pkginfo.name}' download size: {task.download_size}")
        if not self.installer.confirm_task(task):
            return
        self.installer.execute_task(task)

    def on_installer_info_error(self, task):
        print(f"Flatpak update error: '{task.error_message}'")

    def on_installer_finished(self, task):
        print(f"Flatpak '{self.pkginfo.name}' finished")

    def on_installer_progress(self, task, progress, estimating, status_text=None):
        print(f"Flatpak '{self.pkginfo.name}' progress: {progress}")


