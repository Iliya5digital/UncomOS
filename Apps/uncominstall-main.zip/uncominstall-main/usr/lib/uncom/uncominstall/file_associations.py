import os
import threading
import json
import urllib

import yaml
import requests
import multiprocessing
from pathlib import Path
from gi.repository import GLib, GObject

from misc import print_timing


class FileAssociationsCache(object):
    def __init__(self, associations: dict, size: int):
        super(FileAssociationsCache, self).__init__()

        self.associations = associations
        self.size = int(size)

    @classmethod
    def empty(cls):
        return cls({}, 0)


    @classmethod
    def from_yaml(cls, yaml_data: dict, size: int):
        return cls(yaml_data["associations"], size)

    @classmethod
    def from_json(cls, json_data: dict):
        cache_data = json_data["associations"]
        return cls(cache_data, json_data["size"])


class FileAssociations(GObject.Object):
    CACHE_DIR = os.path.join(GLib.get_user_cache_dir(), "uncominstall")
    CONFIG_CACHE_NAME = "file_association.json"
    CONFIG_CACHE_PATH = os.path.join(CACHE_DIR, CONFIG_CACHE_NAME)
    LOCAL_DIR = "/usr/share/uncom/uncominstall/"
    SERVER_URL = "https://download.uncom.tech/uncom-install/"
    CONFIG_SERVER_NAME = "file_associations.yaml"
    CONFIG_SERVER_URL = urllib.parse.urljoin(SERVER_URL, CONFIG_SERVER_NAME)

    __gsignals__ = {
        'file-associations-initialized': (GObject.SignalFlags.RUN_LAST, None, (bool,)),
    }

    @print_timing
    def __init__(self):
        GObject.Object.__init__(self)

        self._cache_lock = threading.Lock()

        self._cache = self._load_cache()
        if len(self) == 0:
            self._cache = self._restore_default_associations()

        self.proc = None

        self._update_cache()

    def is_process(self):
        return self.proc is not None

    def kill(self):
        try:
            self.proc.terminate()
            self.proc = None
        except AttributeError as e:
            pass

    def keys(self):
        with self._cache_lock:
            return self._cache.associations.keys()

    def values(self):
        with self._cache_lock:
            return self._cache.associations.values()

    def __getitem__(self, key):
        with self._cache_lock:
            try:
                return self._cache.associations[key]
            except KeyError:
                return {}

    def __contains__(self, name):
        with self._cache_lock:
            return name in self._cache.associations

    def __len__(self):
        with self._cache_lock:
            return len(self._cache.associations)

    def _load_cache(self):
        cache = FileAssociationsCache.empty()

        path = None

        try:
            path = Path(self.CONFIG_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            if path is not None:
                try:
                    with path.open(mode='r', encoding="utf8") as f:
                        cache = FileAssociationsCache.from_json(json.load(f))
                except Exception as e:
                    print("UncomInstall: Cannot open file associations cache. File path: %s" % self.CONFIG_CACHE_PATH)
        return cache

    def _save_cache(self, cache: FileAssociationsCache):
        path = {}

        try:
            path = Path(self.CONFIG_CACHE_PATH)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            try:
                with path.open(mode='w', encoding="utf8") as f:
                    json.dump(cache, f, default=lambda o: o.__dict__, indent=4)
            except Exception as e:
                print("UncomInstall: Could not save file associations cache. File path: %s" % self.CONFIG_CACHE_PATH)

    def _update_cache(self):
        thread = threading.Thread(target=self._update_associations_thread)
        thread.start()

    @print_timing
    def _update_associations_thread(self):

        success = multiprocessing.Value('b', False)

        current_size = multiprocessing.Value('d', self._cache.size)
        self.proc = multiprocessing.Process(target=self._update_cache_process, args=(success, current_size))
        self.proc.start()

        self.proc.join()

        self.proc = None

        if success.value:
            with self._cache_lock:
                self._cache = self._load_cache()
        GLib.idle_add(self.emit_associations_updated, success.value)

    def emit_associations_updated(self, success: bool):
        self.emit("file-associations-initialized", success)

    def _update_cache_process(self, success: bool, current_size: int):
        cache, result = self._download_associations(current_size)
        if not result:
            success.value = False
            return
        self._save_cache(cache)
        success.value = True

    def _download_associations(self, current_size: int):
        cache = FileAssociationsCache.empty()
        result = False
        try:
            r = requests.head(self.CONFIG_SERVER_URL, timeout=2)
            size = int(r.headers.get("Content-Length"))
            if r.status_code == 200:
                if size != current_size.value:
                    r = requests.get(self.CONFIG_SERVER_URL, timeout=30)
                    yaml_data = yaml.safe_load(r.text)
                    cache = FileAssociationsCache.from_yaml(yaml_data, size)
                    print("UncomInstall: Downloaded new file associations")
                    result = True
                else:
                    print("UncomInstall: No new file associations")
            else:
                print("UncomInstall: Could not download updated file associations: %s" % r.reason)
        except Exception as e:
            print("UncomInstall: Problem attempting to access file associations url: %s" % self.CONFIG_SERVER_URL)
        return cache, result

    def _restore_default_associations(self):
        cache, result = self._load_local_associations()
        if not result:
            return cache
        self._save_cache(cache)
        return cache

    def _load_local_associations(self):
        cache = FileAssociationsCache.empty()
        result = False
        file_path = os.path.join(self.LOCAL_DIR, self.CONFIG_SERVER_NAME)
        try:
            size = os.path.getsize(file_path)
            with open(file_path, 'r', encoding="utf-8") as file:
                yaml_data = yaml.safe_load(file)
                cache = FileAssociationsCache.from_yaml(yaml_data, size)
                print("UncomInstall: Load default file associations")
                result = True
        except Exception as e:
            print("UncomInstall: Problem attempting to access default file associations : %s" % file_path)
        return cache, result

    def get_package_name(self, file_path):
        package_name = None
        base_name = os.path.basename(file_path).lower()
        file_extension = os.path.splitext(file_path)[1]
        if file_extension:
            file_extension = file_extension[1:]
        patterns = self._cache.associations.get(file_extension)
        if patterns is None:
            return None
        for pattern in patterns.keys():
            if pattern == "":
                continue
            if pattern.lower() in base_name:
                package_name = patterns.get(pattern)
        if package_name is None:
            package_name = patterns.get("")
        return package_name

