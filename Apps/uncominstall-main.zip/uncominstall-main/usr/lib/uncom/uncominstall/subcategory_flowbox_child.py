import gettext
from gi.repository import Gtk

_ = gettext.gettext

class SubcategoryFlowboxChild(Gtk.FlowBoxChild):
    def __init__(self, category, is_all=False, active=False):
        super(Gtk.FlowBoxChild, self).__init__()

        self.category = category

        if is_all:
            cat_name = _("All")
        else:
            cat_name = category.name

        self.button = Gtk.ToggleButton(label=cat_name, active=active)
        self.add(self.button)

        self.button.connect("clicked", self._activate_fb_child)

    def _activate_fb_child(self, widget):
        self.activate()
