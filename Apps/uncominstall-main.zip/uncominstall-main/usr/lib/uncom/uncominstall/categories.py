import os
import threading
import yaml
import json
import requests
import multiprocessing
from pathlib import Path
from gi.repository import GLib, GObject

from misc import print_timing
from enum import Enum

class CategoryDesc(object):

    def __init__(self, list, children=None):
        if children is None:
            children = []
        self.list = list
        self.children = children

    @classmethod
    def empty(cls):
        return cls([], [])

    @classmethod
    def from_json(cls, json_data:dict):
        return cls(**json_data)

class CategoryCache(object):
    def __init__(self, categories:dict, size:int):
        super(CategoryCache, self).__init__()

        self.categories = categories
        self.size = int(size)

    @classmethod
    def empty(cls):
        return cls({}, 0)

    @classmethod
    def from_json(cls, json_data: dict):
        new_dict = {}
        cache_data = json_data["categories"]
        for key in cache_data.keys():
            info_data = cache_data[key]
            new_dict[key] = CategoryDesc.from_json(info_data)

        return cls(new_dict, json_data["size"])

    @classmethod
    def from_yaml(cls, yaml_data: dict, size):
        new_dict = {}
        categories_data = yaml_data["categories"]
        for key in categories_data.keys():
            category_data = categories_data[key]
            new_dict[key] = CategoryDesc.from_json(category_data)
        return cls(new_dict, size)

class Categories(GObject.Object):
    FEATURED_LIST_PATH = os.path.join(GLib.get_user_cache_dir(), "uncominstall")
    CATEGORIES_CACHE = os.path.join(FEATURED_LIST_PATH, "categories.json")
    CATEGORIES_DEFAULT_PATH = "/usr/share/uncom/uncominstall/categories/"
    CATEGORIES_URL = "https://download.uncom.tech/uncom-install/categories/categories.yaml"

    __gsignals__ = {
        'categories-initialized': (GObject.SignalFlags.RUN_LAST, None, (bool,)),
    }
    @print_timing
    def __init__(self):
        GObject.Object.__init__(self)

        self._cache_lock = threading.Lock()

        self._cache = self._load_cache()
        if len(self) == 0:
            self._cache = self._restore_default_categories()

        self.proc = None

        self._update_cache()

    def is_loading(self):
        with self._cache_lock:
            return self.proc is not None

    def kill(self):
        try:
            self.proc.terminate()
            self.proc = None
        except AttributeError as e:
            pass

    def keys(self):
        with self._cache_lock:
            return self._cache.categories.keys()

    def values(self):
        with self._cache_lock:
            return self._cache.categories.values()

    def __getitem__(self, key):
        with self._cache_lock:
            try:
                return self._cache.categories[key]
            except KeyError:
                return CategoryDesc.empty()

    def __contains__(self, name):
        with self._cache_lock:
            return name in self._cache.categories

    def __len__(self):
        with self._cache_lock:
            return len(self._cache.categories)

    def get_category_list(self, category_name):
        if category_name in self._cache.categories:
            return self._cache.categories[category_name].list
        return []

    def _load_cache(self):
        cache = CategoryCache.empty()
        path = None

        try:
            path = Path(self.CATEGORIES_CACHE)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            if path is not None:
                try:
                    with path.open(mode='r', encoding="utf8") as f:
                        cache = CategoryCache.from_json(json.load(f))
                except Exception as e:
                    print("UncomInstall: Cannot open categories cache. File path: %s" % self.CATEGORIES_CACHE)

        return cache

    def _save_cache(self, cache:CategoryCache):
        path = {}

        try:
            path = Path(self.CATEGORIES_CACHE)
            path.parent.mkdir(parents=True, exist_ok=True)
        except Exception:
            path = None
        finally:
            try:
                with path.open(mode='w', encoding="utf8") as f:
                    json.dump(cache, f, default=lambda o: o.__dict__, indent=4)
            except Exception as e:
                print("UncomInstall: Could not save categories cache. File path: %s" % self.CATEGORIES_CACHE)

    def _update_cache(self):
        thread = threading.Thread(target=self._update_categories_thread)
        thread.start()

    @print_timing
    def _update_categories_thread(self):
        success = multiprocessing.Value('b', False)
        current_size = multiprocessing.Value('d', self._cache.size)

        self.proc = multiprocessing.Process(target=self._update_cache_process, args=(success, current_size))
        self.proc.start()

        self.proc.join()

        self.proc = None

        if success.value:
            with self._cache_lock:
                self._cache = self._load_cache()

        GLib.idle_add(self.emit_categories_initialized, success.value)

    def emit_categories_initialized(self, success: bool):
        self.emit("categories-initialized", success)

    def _update_cache_process(self, success, current_size):
        cache, result = self.download_categories(current_size.value)
        if not result:
            success.value = False
            return
        self._save_cache(cache)
        success.value = True

    def download_categories(self, current_size):
        cache = CategoryCache.empty()
        result = False
        try:
            r = requests.head(self.CATEGORIES_URL, timeout=2)
            size = int(r.headers.get("Content-Length"))
            if r.status_code == 200:
                if size != current_size:
                    r = requests.get(self.CATEGORIES_URL, timeout=30)
                    yaml_data = yaml.safe_load(r.text)
                    cache = CategoryCache.from_yaml(yaml_data, size)
                    print("UncomInstall: Downloaded new categories")
                    result = True
                else:
                    print("UncomInstall: No new categories")
            else:
                print("UncomInstall: Could not download updated categories: %s" % r.reason)
        except Exception as e:
            print("UncomInstall: Problem attempting to access categories url: %s" % self.CATEGORIES_URL)
        return cache, result

    def _restore_default_categories(self):
        cache, result = self._load_default_categories()
        if not result:
            return cache
        self._save_cache(cache)
        return cache

    def _load_default_categories(self):
        cache = CategoryCache.empty()
        result = False
        file_path = os.path.join(self.CATEGORIES_DEFAULT_PATH, "categories.yaml")
        try:
            size = os.path.getsize(file_path)
            with open(file_path, 'r', encoding="utf-8") as file:
                yaml_data = yaml.safe_load(file)
                cache = CategoryCache.from_yaml(yaml_data, size)
                print("UncomInstall: Load default categories")
                result = True
        except Exception as e:
            print("UncomInstall: Problem attempting to access default categories : %s" % file_path)
        return cache, result
