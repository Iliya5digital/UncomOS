#!/usr/bin/python3

import sys
import gi
import subprocess
import time
import os
import pwd
import shlex
gi.require_version('Gtk', '4.0')
gi.require_version('Adw', '1')
from gi.repository import Gtk, Adw, Gdk, Gio
from PIL import Image
import random
import string
import yaml
import argparse

USER_BACKUP_FOLDER_PATH = "~/.var/uncom-restore"
SYSTEM_BACKUP_FOLDER_PATH = "/var/uncom-restore"
RESTORE_POINT_CONFIG_NAME = "restore-point.yaml"

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.set_default_size(700, 350)
        self.set_title("Восстановление целостности системы")
        self.set_resizable(False)

        self.main_box = Gtk.Box(spacing=0, orientation=Gtk.Orientation.VERTICAL)
        self.set_child(self.main_box)
        self.main_box.set_margin_start(20)
        self.main_box.set_margin_end(20)
        self.main_box.set_margin_top(20)
        self.main_box.set_margin_bottom(20)

        self.box = Gtk.Box(spacing=5, orientation=Gtk.Orientation.VERTICAL)
        self.main_box.append(self.box)  

        self.box_title = Gtk.Box(spacing=0, orientation=Gtk.Orientation.HORIZONTAL)
        self.box.append(self.box_title) 

        self.picture = Gtk.Picture.new_for_filename("/usr/lib/uncom/uncom-restore/uncom-restore.png")
        self.picture.set_margin_end(10)
        self.picture.set_margin_start(-5)
        self.box_title.append(self.picture)

        self.label_title = Gtk.Label()
        self.label_title.set_markup("<big>Восстановление целостности\nсистемы Uncom OS</big>")
        self.label_title.set_wrap(True)
        self.label_title.set_justify(Gtk.Justification.LEFT)
        self.label_title.set_xalign(0)
        self.label_title.set_margin_start(0)
        self.label_title.set_margin_end(0)
        self.label_title.set_margin_top(10)
        self.label_title.set_margin_bottom(10)
        self.box_title.append(self.label_title)

        self.box_buttons = Gtk.Box(spacing=0, orientation=Gtk.Orientation.VERTICAL)
        self.box_buttons.set_margin_top(10)
        self.main_box.append(self.box_buttons)


        # -------------------------


        self.label_title1 = Gtk.Label()
        self.label_title1.set_markup("<big>Восстановление системы</big>")
        self.label_title1.set_margin_top(20)
        self.label_title1.set_wrap(True)
        self.label_title1.set_xalign(0)
        self.label_title1.set_justify(Gtk.Justification.LEFT)
        self.box_buttons.append(self.label_title1)

        self.label1 = Gtk.Label(label="Процесс занимает несколько минут и не затрагивает ваши файлы. После восстановления возможно, что некоторые приложения придется перенастроить заново. Для восстановления используется системная информация на момент первого запуска ОС после ее установки.")
        self.label1.set_wrap(True)
        self.label1.set_justify(Gtk.Justification.LEFT)
        self.label1.set_xalign(0)
        self.label1.set_margin_top(10)
        self.box_buttons.append(self.label1)

        self.button_restore_system = Gtk.Button(label="Восстановить репозитории и предустановленные приложения")
        self.button_restore_system.set_margin_top(10)
        self.button_restore_system.connect("clicked", self.on_button_restore_system_clicked)
        self.box_buttons.append(self.button_restore_system)

        self.label3 = Gtk.Label(label="В случаях ошибок с деревом зависимостей программных пакетов его целостность можно исправить. Процесс исправления может занять несколько минут.")
        self.label3.set_wrap(True)
        self.label3.set_justify(Gtk.Justification.LEFT)
        self.label3.set_xalign(0)
        self.label3.set_margin_top(10)
        self.box_buttons.append(self.label3)

        self.button_fix_repos = Gtk.Button(label="Исправить дерево зависимостей")
        self.button_fix_repos.set_margin_top(10)
        self.button_fix_repos.connect("clicked", self.on_button_fix_repos_clicked)
        self.box_buttons.append(self.button_fix_repos)


        # -------------------------


        self.label_title2 = Gtk.Label()
        self.label_title2.set_markup("<big>Управление списком репозиториев</big>")
        self.label_title2.set_margin_top(40)
        self.label_title2.set_wrap(True)
        self.label_title2.set_xalign(0)
        self.label_title2.set_justify(Gtk.Justification.LEFT)
        self.box_buttons.append(self.label_title2)

        self.label2 = Gtk.Label(label="Процесс занимает несколько минут и не затрагивает ваши файлы и программы. Сохранению и восстановлению подлежит только список репозиториев и ключи шифрования для доступа к ним.")
        self.label2.set_wrap(True)
        self.label2.set_justify(Gtk.Justification.LEFT)
        self.label2.set_xalign(0)
        self.label2.set_margin_top(10)
        self.box_buttons.append(self.label2)

        self.label_last_repos_save = Gtk.Label(label="Последнее сохранение: 2023.11.01 17:15")
        self.label_last_repos_save.set_justify(Gtk.Justification.LEFT)
        self.label_last_repos_save.set_margin_start(0)
        self.label_last_repos_save.set_margin_top(10)
        self.label_last_repos_save.set_xalign(0)
        self.box_buttons.append(self.label_last_repos_save)

        self.box_buttons_point = Gtk.Box(spacing=5, orientation=Gtk.Orientation.HORIZONTAL)
        self.box_buttons_point.set_margin_top(10)
        self.box_buttons_point.set_hexpand(True)
        self.box_buttons.append(self.box_buttons_point)

        self.button_save_repos = Gtk.Button(label="Сохранить список репозиториев")
        self.button_save_repos.set_hexpand(True)
        self.button_save_repos.connect("clicked", self.on_button_save_repos_clicked)
        self.box_buttons_point.append(self.button_save_repos)

        self.button_load_repos = Gtk.Button(label="Восстановить список репозиториев")
        self.button_load_repos.set_hexpand(True)
        self.button_load_repos.connect("clicked", self.on_button_load_repos_clicked)
        self.box_buttons_point.append(self.button_load_repos)

        self.box_spinner = Gtk.Box(spacing=5, orientation=Gtk.Orientation.HORIZONTAL)
        self.box_spinner.set_margin_top(10)
        self.box_buttons.append(self.box_spinner)

        self.spinner = Gtk.Spinner()
        self.box_spinner.append(self.spinner)
        
        self.label_spinner = Gtk.Label()
        self.label_spinner.set_markup("<small>Подождите, это займет несколько минут ...</small>")
        self.label_spinner.set_visible(False)
        self.box_spinner.append(self.label_spinner)

        self.refresh_state()

        self.header = Gtk.HeaderBar()
        self.set_titlebar(self.header)

        def show_about_dialog(action, param):
            print("Show about dialog")    
            self.about = Gtk.AboutDialog()
            self.about.set_program_name("Восстановление системы")
            self.about.set_transient_for(self)  # Makes the dialog always appear in from of the parent window
            self.about.set_modal(self)  # Makes the parent window unresponsive while dialog is showing

            self.about.set_copyright("Copyright 2024 Uncom OS")
            self.about.set_license_type(Gtk.License.GPL_3_0)
            self.about.set_website("http://uncom.tech")
            self.about.set_website_label("Веб-страница")
            self.about.set_version("1.0")
            # The icon will need to be added to appropriate location
            # E.g. /usr/share/icons/hicolor/scalable/apps/org.example.example.svg
            self.about.set_logo_icon_name("gnome-control-center")
            self.about.set_visible(True)

        action = Gio.SimpleAction.new("show_about_dialog", None)
        action.connect("activate", show_about_dialog)
        self.add_action(action)    

        def open_backup_directory(action, param):
            print("Open backup directory in Nautilus") 
            subprocess.Popen(["open", self.USER_BACKUP_FOLDER_PATH_EXPANDED])
            # print(subprocess.run(["nautilus", USER_BACKUP_FOLDER_PATH], capture_output=True))

        action2 = Gio.SimpleAction.new("open_backup_directory", None)
        action2.connect("activate", open_backup_directory)
        self.add_action(action2)  

        # Create a new menu, containing that action
        menu = Gio.Menu.new()
        menu.append("Открыть папку с точками восстановления", "win.open_backup_directory")   
        menu.append("О приложении", "win.show_about_dialog")                

        # Create a popover
        self.popover = Gtk.PopoverMenu()  # Create a new popover menu
        self.popover.set_menu_model(menu)

        # Create a menu button
        self.hamburger = Gtk.MenuButton()
        self.hamburger.set_popover(self.popover)
        self.hamburger.set_icon_name("open-menu-symbolic")  # Give it a nice icon

        # Add menu button to the header bar
        self.header.pack_start(self.hamburger)


    def show_message_info(self, message):
        self.dialog = Gtk.MessageDialog(
            transient_for=self,
            message_type=Gtk.MessageType.INFO,
            buttons=Gtk.ButtonsType.OK,
            text=message,
        )

        def close_dialog(self, app):
            self.destroy()

        self.dialog.connect('response', close_dialog)
        self.dialog.set_modal(self)
        self.dialog.present()
    
    def refresh_state(self):
        print("Current directory: " + os.getcwd())
        self.USER_BACKUP_FOLDER_PATH_EXPANDED = os.path.expanduser(USER_BACKUP_FOLDER_PATH)
        print("Look up backup directory: " + self.USER_BACKUP_FOLDER_PATH_EXPANDED)
    
        if os.path.isdir(self.USER_BACKUP_FOLDER_PATH_EXPANDED):
            for dirname, dirnames, filenames in os.walk(self.USER_BACKUP_FOLDER_PATH_EXPANDED):
                for subdirname in sorted(dirnames, reverse=True):
                    print("Checking directory for backup: " + os.path.join(dirname, subdirname))
                    if os.path.isfile(os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME)):
                        print("Found backup directory: " + os.path.join(dirname, subdirname))
                        print("Found config file inside: " + os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME))
                        self.CURRENT_BACKUP_DIR = os.path.join(dirname, subdirname)
                        self.CURRENT_BACKUP_FILE = os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME)
                        try:
                            with open(self.CURRENT_BACKUP_FILE, "r") as yamlfile:
                                data = yaml.load(yamlfile, Loader=yaml.FullLoader)
                                timestamp = data["creation-timestamp"]
                                print("Creation timestamp: " + str(timestamp))
                                time_obj = time.localtime(timestamp)
                                time_printable = time.strftime("%Y.%m.%d %H:%M:%S", time_obj)
                                print("Creation time (human readable): " + time_printable)
                                self.label_last_repos_save.set_label("Последнее сохранение: " + time_printable)
                                self.button_load_repos.set_sensitive(True)
                                self.button_save_repos.set_sensitive(True)
                                self.button_restore_system.set_sensitive(True)
                                self.button_fix_repos.set_sensitive(True)
                                return
                        except:
                            continue

        print("No backup directory found, first start of the app")
        self.label_last_repos_save.set_label("Сохраненных списков репозиториев пока еще нет...")
        self.button_load_repos.set_sensitive(False)
        self.button_save_repos.set_sensitive(True)
        self.button_restore_system.set_sensitive(True)
        self.button_fix_repos.set_sensitive(True)

    def on_button_restore_system_clicked(self, widget):
        print("Perform wau back from system restore point...") 
        print("Look up backup directory: " + SYSTEM_BACKUP_FOLDER_PATH)

        if os.path.isdir(SYSTEM_BACKUP_FOLDER_PATH):
            for dirname, dirnames, filenames in os.walk(SYSTEM_BACKUP_FOLDER_PATH):
                for subdirname in sorted(dirnames, reverse=True):
                    print("Checking directory for backup: " + os.path.join(dirname, subdirname))
                    print("file: " + os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME))
                    if os.path.isfile(os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME)):
                        print("Found backup directory: " + os.path.join(dirname, subdirname))
                        print("Found config file inside: " + os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME))
                        CURRENT_BACKUP_DIR = os.path.join(dirname, subdirname)
                        CURRENT_BACKUP_FILE = os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME)
                        try:
                            with open(CURRENT_BACKUP_FILE, "r") as yamlfile:
                                data = yaml.load(yamlfile, Loader=yaml.FullLoader)
                                timestamp = data["creation-timestamp"]
                                print("Creation timestamp: " + str(timestamp))
                                time_obj = time.localtime(timestamp)
                                time_printable = time.strftime("%Y.%m.%d %H:%M:%S", time_obj)
                                print("Creation time (human readable): " + time_printable)

                                self.button_save_repos.set_sensitive(False)
                                self.button_load_repos.set_sensitive(False)
                                self.label_spinner.set_visible(True)
                                self.spinner.start()

                                proc = Gio.Subprocess.new(shlex.split("pkexec sh -c " + 
                                    """
                                    'cd "{directory}" && 
                                    sudo apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite"  && 
                                    sudo apt-clone restore app-storage.tar.gz && 
                                    sudo dpkg --clear-selections && 
                                    sudo dpkg --set-selections < app-list.txt && 
                                    sudo apt-get dselect-upgrade -y'
                                    """.format(directory = CURRENT_BACKUP_DIR)), 0)
                                proc.wait_check_async(None, self._restoration_finished)
                                return
                        except:
                            continue

        print("No backup directory found in system space, first of all you need to create a restore point")
        self.show_message_info("Системных точек восстановления не найдено, они создаются автоматически после установки ОС на компьютер или крупных обновлений. Системные точки восстановления могут отсутствовать для ранних версий ОС.")
        self.spinner.stop()
        self.label_spinner.set_visible(False)
        self.refresh_state()  

    def on_button_fix_repos_clicked(self, widget):
        print("Fixing dependency tree...") 
        self.button_save_repos.set_sensitive(False)
        self.button_load_repos.set_sensitive(False)
        self.button_restore_system.set_sensitive(False)
        self.button_fix_repos.set_sensitive(False)
        self.label_spinner.set_visible(True)
        self.spinner.start()

        proc = Gio.Subprocess.new(shlex.split("pkexec sh -c " + 
            """
            'sudo apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite"'
            """), 0)
        proc.wait_check_async(None, self._fix_dependency_tree_finished)

    def on_button_save_repos_clicked(self, widget):
        print("Creating new restore point with repos list...")
        self.button_save_repos.set_sensitive(False)
        self.button_load_repos.set_sensitive(False)
        self.button_restore_system.set_sensitive(False)
        self.button_fix_repos.set_sensitive(False)
        self.label_spinner.set_visible(True)
        self.spinner.start()

        if not os.path.isdir(self.USER_BACKUP_FOLDER_PATH_EXPANDED):
            os.makedirs(self.USER_BACKUP_FOLDER_PATH_EXPANDED)
        
        self.creation_time = time.time()

        subdirname = "restore-point-" + str(time.strftime("%Y.%m.%d-%H.%M.%S", time.localtime(self.creation_time)))
        self.CURRENT_BACKUP_DIR = os.path.join(self.USER_BACKUP_FOLDER_PATH_EXPANDED, subdirname)
        self.CURRENT_BACKUP_FILE = os.path.join(self.CURRENT_BACKUP_DIR, RESTORE_POINT_CONFIG_NAME)

        print("Current backup directory: " + self.CURRENT_BACKUP_DIR)
        print("Current config file inside: " + self.CURRENT_BACKUP_FILE)

        if not os.path.isdir(self.CURRENT_BACKUP_DIR):
            os.makedirs(self.CURRENT_BACKUP_DIR)

        current_user = subprocess.getoutput("whoami")
        
        proc = Gio.Subprocess.new(shlex.split("pkexec sh -c " + 
            """
            'cd "{directory}" && 
            sudo apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite" && 
            sudo apt-clone clone app-storage.tar.gz && 
            sudo dpkg --get-selections > app-list.txt && 
            sudo chown {username}:{username} app-storage.tar.gz && 
            sudo chown {username}:{username} app-list.txt && 
            sudo chmod g+w app-storage.tar.gz && 
            sudo chmod g+w app-list.txt'
            """.format(username = current_user, directory = self.CURRENT_BACKUP_DIR)), 0)
        proc.wait_check_async(None, self._save_repos_finished)
        
    def on_button_load_repos_clicked(self, widget):
        print("Restoring repos list from selected point...")
        self.button_save_repos.set_sensitive(False)
        self.button_load_repos.set_sensitive(False)
        self.button_restore_system.set_sensitive(False)
        self.button_fix_repos.set_sensitive(False)
        self.label_spinner.set_visible(True)
        self.spinner.start()

        proc = Gio.Subprocess.new(shlex.split("pkexec sh -c " + 
            """
            'cd "{directory}" && 
            sudo apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite"  && 
            sudo apt-clone restore app-storage.tar.gz'
            """.format(directory = self.CURRENT_BACKUP_DIR)), 0)
        proc.wait_check_async(None, self._load_repos_finished)
        
    def _load_repos_finished(self, subprocess, result):
        if subprocess.get_successful() == False:
            print("Failed to restore list of repos.")
            self.show_message_info("Ошибка при восстановлении списка репозиториев")
        else:
            print("List of repos successfully restored.")
            self.show_message_info("Репозитории восстановлены, рекомендуем перезагрузить компьютер")

        self.spinner.stop()
        self.label_spinner.set_visible(False)
        self.refresh_state()  

    def _save_repos_finished(self, subprocess, result):
        if subprocess.get_successful() == False:
            print("Failed to save list of repos.")
            self.show_message_info("Ошибка при сохранении списка репозиториев")
        else:
            with open(self.CURRENT_BACKUP_FILE, 'w') as yamlfile:
                data = yaml.dump({"version" : "1.0", "creation-timestamp": self.creation_time}, yamlfile)
            print("List of repos successfully saved.")
            self.show_message_info("Список репозиториев и ключи к ним сохранены")

        self.spinner.stop()
        self.label_spinner.set_visible(False)
        self.refresh_state() 
    
    def _restoration_finished(self, subprocess, result):
        if subprocess.get_successful() == False:
            print("System failed to restore.")
            self.show_message_info("Ошибка при восстановлении системы")
        else:
            print("System successfully restored.")
            self.show_message_info("Система восстановлена, рекомендуем перезагрузить компьютер")

        self.spinner.stop()
        self.label_spinner.set_visible(False)
        self.refresh_state()  

    def _fix_dependency_tree_finished(self, subprocess, result):
        if subprocess.get_successful() == False:
            print("Fixing dependency tree failed.")
            self.show_message_info("Ошибка при исправлении дерева зависимостей, обратитесь в техническую поддержку Uncom OS")
        else:
            print("Fixing dependency tree successfully done.")
            self.show_message_info("Дерево зависимостей пакетов исправлено")

        self.spinner.stop()
        self.label_spinner.set_visible(False)
        self.refresh_state() 




class MyApp(Adw.Application):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.connect('activate', self.on_activate)

    def on_activate(self, app):
        self.win = MainWindow(application=app)
        self.win.present()

parser = argparse.ArgumentParser(
    description="Uncom OS tool to fix dependency tree, create and way back to restore points.",
    epilog="Start without parameters to open GUI version (works in user space).")

group = parser.add_mutually_exclusive_group(required=False)
group.add_argument('-f', '--fix', action='store_true', help='Fix dependency tree')
group.add_argument('-c', '--create', action='store_true', help='Create restore point (system space)')
group.add_argument('-r', '--restore', action='store_true', help='Way back to the last restore point (system space)')
parser.add_argument('--with-dpkg-repack', action='store_true', help='Include .deb packages from external sources (system space)', dest='dpkg')

args = parser.parse_args()

print("Running application as: " + os.getlogin())

if args.fix:
    print("Running in Terminal mode: fix dependency tree")
    if os.geteuid() != 0:
        sys.exit("ERROR: You need root permissions, launch with sudo")

    retcode = os.system( 
        """
        apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite"
        """)

    if retcode == 0:
        print("Fixing dependency tree successfully done.")
        exit(0)
    else:
        exit( 1)

elif args.create:
    print("Running in Terminal mode: create restore point")
    if os.geteuid() != 0:
        sys.exit("ERROR: You need root permissions, launch with sudo")

    if not os.path.isdir(SYSTEM_BACKUP_FOLDER_PATH):
        os.makedirs(SYSTEM_BACKUP_FOLDER_PATH)
    
    creation_time = time.time()

    subdirname = "restore-point-" + str(time.strftime("%Y.%m.%d-%H.%M.%S", time.localtime(creation_time)))
    CURRENT_BACKUP_DIR = os.path.join(SYSTEM_BACKUP_FOLDER_PATH, subdirname)
    CURRENT_BACKUP_FILE = os.path.join(CURRENT_BACKUP_DIR, RESTORE_POINT_CONFIG_NAME)

    print("Current backup directory: " + CURRENT_BACKUP_DIR)
    print("Current config file inside: " + CURRENT_BACKUP_FILE)

    if not os.path.isdir(CURRENT_BACKUP_DIR):
        os.makedirs(CURRENT_BACKUP_DIR)
    
    retcode = os.system( 
        """
        cd "{directory}" && 
        apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite" && 
        apt-clone clone app-storage.tar.gz {dpkg} && 
        dpkg --get-selections > app-list.txt
        """.format(directory = CURRENT_BACKUP_DIR, dpkg = "--with-dpkg-repack" if args.dpkg else ""))
    
    if retcode == 0:
        with open(CURRENT_BACKUP_FILE, 'w') as yamlfile:
            data = yaml.dump({"version" : "1.0", "creation-timestamp": creation_time}, yamlfile)
        print("Restore point successfully created.")
        exit(0)
    else:
        exit(1)

elif args.restore:
    print("Running in Terminal mode: way back to last restore point")
    if os.geteuid() != 0:
        sys.exit("ERROR: You need root permissions, launch with sudo")

    print("Look up backup directory: " + SYSTEM_BACKUP_FOLDER_PATH)
    retcode = 0
    if os.path.isdir(SYSTEM_BACKUP_FOLDER_PATH):
        for dirname, dirnames, filenames in os.walk(SYSTEM_BACKUP_FOLDER_PATH):
            for subdirname in sorted(dirnames, reverse=True):
                print("Checking directory for backup: " + os.path.join(dirname, subdirname))
                print("file: " + os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME))
                if os.path.isfile(os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME)):
                    print("Found backup directory: " + os.path.join(dirname, subdirname))
                    print("Found config file inside: " + os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME))
                    CURRENT_BACKUP_DIR = os.path.join(dirname, subdirname)
                    CURRENT_BACKUP_FILE = os.path.join(dirname, subdirname, RESTORE_POINT_CONFIG_NAME)
                    try:
                        with open(CURRENT_BACKUP_FILE, "r") as yamlfile:
                            data = yaml.load(yamlfile, Loader=yaml.FullLoader)
                            timestamp = data["creation-timestamp"]
                            print("Creation timestamp: " + str(timestamp))
                            time_obj = time.localtime(timestamp)
                            time_printable = time.strftime("%Y.%m.%d %H:%M:%S", time_obj)
                            print("Creation time (human readable): " + time_printable)

                            retcode = os.system( 
                                """
                                cd "{directory}" && 
                                apt --fix-broken install -y -o Dpkg::Options::="--force-overwrite"  && 
                                apt-clone restore app-storage.tar.gz && 
                                dpkg --clear-selections && 
                                dpkg --set-selections < app-list.txt && 
                                apt-get dselect-upgrade -y
                                """.format(directory = CURRENT_BACKUP_DIR))
                    except:
                        continue
    if retcode == 0:
        print("System successfully restored.")
        exit(0)
    else:
        print("No backup directory found, first of all you need to create a restore point")
        exit(1)

else:
    print("Running in GUI mode")
    main_app = MyApp(application_id="tech.uncom.restore")
    main_app.run()



