Uncom-Restore

This tool allows to add restore points of the system and wayback to them, fix dependency tree.

To build package:
```debuild --no-tgz-check -uc -us```