#!/bin/bash

release_file="/usr/share/uncom/uncom_setup.release"
# we need sort + tail cause in the moment there are two versions installed.
# we get the smaller cause it is the updating one
version=`dpkg -s uncom-setup | grep Version | awk -F \:\  '{print $NF}' | sort | head -1`

# andromeda repos starting from this version
# No need to update sources.list
no_jammy_version="0.4"

echo "$version" > $release_file

# Function for version comparison
# Everything is comma separated
vercomp () {
    if [[ $1 == $2 ]]
    then
        return 0
    fi
    local IFS=.
    local i ver1=($1) ver2=($2)
    # fill empty fields in ver1 with zeros
    for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
    do
        ver1[i]=0
    done
    for ((i=0; i<${#ver1[@]}; i++))
    do
        if [[ -z ${ver2[i]} ]]
        then
            # fill empty fields in ver2 with zeros
            ver2[i]=0
        fi
        if ((10#${ver1[i]} > 10#${ver2[i]}))
        then
            return 1
        fi
        if ((10#${ver1[i]} < 10#${ver2[i]}))
        then
            return 2
        fi
    done
    return 0
}

echo "version = $version, no_jammy_version = $no_jammy_version"
version_dotted=`echo $version | sed "s/-/./"`
no_jammy_version_dotted=`echo $no_jammy_version | sed "s/-/./"`
echo "version_dotted = $version_dotted, no_jammy_version_dotted = $no_jammy_version_dotted"

vercomp "$version_dotted" "$no_jammy_version_dotted"
case $? in
    0) op='=';;
    1) op='>';;
    2) op='<';;
esac
echo "op is \"$op\""

if [ $op == ">" ]
    then echo "Actual version, no need to update"
        exit 0
    else echo "Proceeding with the update..."
fi

# Remove ubuntu repositories
[ -f /etc/apt/sources.list.d/ubuntu.list ] && {
    rm -f /etc/apt/sources.list.d/ubuntu.list
}

# Update Uncom repositories
mv /etc/apt/sources.list /etc/apt/sources.list.bak
cat <<EOF > /etc/apt/sources.list
deb http://repository.uncom.tech/ andromeda-rebuild main-rebuild
deb http://repository.uncom.tech/ andromeda-updates-rebuild main-rebuild
deb http://repository.uncom.tech/ andromeda main
deb http://repository.uncom.tech/ andromeda-updates main
deb http://repository.uncom.tech/ andromeda-support main
#deb cdrom:[Uncom 2.0 2023.02.28 _Uncommon_ (20230228)]/ andromeda main

EOF


