#!/bin/bash

flatpak list | grep "org.telegram.desktop" || {
echo "No flatpak telegram, exiting..."
exit 0
}

fuser /var/lib/dpkg/lock; code_lock=$?
echo
while [ $code_lock -eq 0 ]
do
    sleep 1
    fuser /var/lib/dpkg/lock; code_lock=$?
done

# Set center-new-windows since we don't have it in old Uncom builds
gsettings set org.gnome.mutter center-new-windows true

line1="У Вас установлена flatpak версия Telegram. <span foreground=\"blue\">Доступна версия в стандартном репозитории</span>."
line2="Это позволит сэкономить место на диске и более оперативно получать обновления."
line3="<span foreground=\"red\"><b>Внимание</b></span>: Вам придется заново войти в аккаунт, локальные настройки Telegram будут сброшены."
line4="Вам также будет необходимо перезапустить сессию Gnome."
ok_label="Установить"
cancel_label="Отмена"
dont_remind="Не напоминать больше"
ans=$(zenity --width=384 --height=128 --question --title "Доступно обновление Telegram"  --text "$line1\n$line2\n\n$line3\n$line4" \
    --ok-label "$ok_label" \
    --cancel-label "$cancel_label" \
    --extra-button "$dont_remind")
code=$?

if [ $code -eq 0 ]
    # Update from flatpak to deb
    then (SUDO_ASKPASS=/sbin/zenity_askpass sudo -A apt install telegram-desktop ) |
            zenity --progress --auto-close \
                --title="Установка" \
                --text="Идет установка, пожалуйста подождите..." \
                --percentage=5
        apt list --installed | grep "telegram-desktop" ; code_install=$?
        if [ $code_install -eq 0 ]
            then sync
                # Removing flatpak only after successfull install of deb version
                flatpak uninstall -y org.telegram.desktop org.telegram.desktop.webview
                #flatpak uninstall -y --unused
                # echo "Update finished, removing task for all admin users..."
                admins=`getent group sudo | awk -F: '{print $4}' |  tr "," " "`
                for user in `echo $admins`
                do
                    sudo rm -f /home/$user/.config/autostart/update_telegram.desktop
                done

                line1="Перезагрузить компьютер сейчас?"
                zenity --width=284 --height=84 --question --title "Обновление завершено"  --text "$line1"; code=$?
                if [ $code -eq 0 ]
                    then reboot
                    else echo "Cancelled"
                fi
            else zenity --width=284 --height=84 --info --title "Внимание!" --text "Произошла ошибка при установке Telegram.\nПопробуйте установить его через Магазин Приложений"
                # echo "Removing task for this user..."
                rm -f $HOME/.config/autostart/update_telegram.desktop
                exit 1
        fi
        sync
        exit 0
    # Cancel or Dont remind again
    else if [[ "$ans" == "$dont_remind" ]]
        then rm -f $HOME/.config/autostart/update_telegram.desktop
        else exit 1
    fi
fi
