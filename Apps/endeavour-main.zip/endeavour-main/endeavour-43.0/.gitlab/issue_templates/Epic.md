# Current problems
<!--
What are the problems that the current project has?

For example:
* User cannot use the keyboard to perform most common actions
or
* User cannot see documents from cloud services
-->

# Goals & use cases
<!--
What are the use cases that this proposal will cover? What are the end goals?

For example:
* User needs to share a file with their friends.
or
* It should be easy to edit a picture within the app.
-->

# Requirements
<!--
What does the solution needs to ensure for being succesful?

For example:
* Work on small form factors and touch
or
* Use the Meson build system and integrate with it
-->

# Relevant art
<!--
Is there any product that has implemented something similar? Put links to other
projects, pictures, links to other code, etc.
-->

# Proposal & plan
<!-- What's the solution and how should be achieved? It can be split in smaller
tasks of minimum change, so they can be delivered across several releases. -->

/label ~"1. Epic"
