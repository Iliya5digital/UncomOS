#include <glib.h>

#define MD6_LITTLE_ENDIAN (G_BYTE_ORDER == G_LITTLE_ENDIAN)

#include "md6_compress.c"
#include "md6_mode.c"
