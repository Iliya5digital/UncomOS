Lilv
====

Lilv is a C library to make the use of LV2 plugins as simple as possible for
applications.
For more information, see <http://drobilla.net/software/lilv>.

 -- David Robillard <d@drobilla.net>
