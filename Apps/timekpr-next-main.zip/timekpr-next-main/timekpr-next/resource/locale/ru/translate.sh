#!/bin/bash

# translate from .po file

[ -z $1 ] && {
    echo "Please provide script with .po file"
    exit 123
}

[ $1 == "--help" ] && {
    echo "./translate.sh [file.po]"
    exit 1
}

file=$1
echo "Working with $file"
rm -f final.po.bak
mv final.po final.po.bak

#cat $file | sed -n '/msgid/,/msgstr/p' | grep -v "msgstr \"" > ./result.po

# Shows whether the translation started
tran=0
line_number=0

while read -r line;
do
    line_number=`expr $line_number \+ 1`
    echo "line = $line ($line_number)"
    echo $line | grep "msgid \"" ; code=$?
    if [ $code -eq 0 ]
    # Translatable
    then echo "THEN 1"
	echo $line | grep "msgid \"\"" ; code2=$?
	if [ $code2 -eq 0 ]
	# String is: msgid ""
	then echo "THEN 1.2"
	    tran=1
	    # print the message to be translated, like:
	    # 		msgid ""
	    # 		"==> set restriction / lockout type (\"lock\" - lock session, \"suspend\" - "
	    # 		"suspend the computer, \"suspendwake\" - suspend and wake up, \"terminate\" - "
	    # 		"terminate sessions, \"shutdown\" - shutdown the computer), examples"
	    sed -n "$line_number,+10p" $file | sed '/msgstr ""/q' | grep -v "msgstr \"\"" >> final.po
	    echo "msgstr \"\"" >> final.po
	# Strings like: msgid "==> set..."
	else echo "ELSE 1.2"
	    #phrase=`echo $line | awk -F msgid '{print $NF}'`
	    #echo "phrase = $phrase"
	    echo $line >> ./final.po
	    trans -b --no-ansi "$line" >> ./final.po
	fi
    # Not translatable
    # Strings like:
    #		#: common/constants/messages.py:41
    #		"==> set time left ...."
    else echo "ELSE 2"
	if [ $tran -eq 1 ]
	# Translation is ongoing
	then echo "THEN 2.1"
	    echo $line | grep "msgstr \"\"" ; code3=$?
	    if [ $code3 -eq 0 ]
	    then echo "THEN 2.2"
		tran=0
	    else echo "ELSE 2.2"
		trans -b --no-ansi "$line" >> ./final.po
	    fi
	else echo "ELSE 2.1"
	    echo $line | grep "msgstr \"\"" || echo $line >> ./final.po
	fi
    fi

done < $file