#!/bin/bash

# translate from .po file

[ -z $1 ] && {
    echo "Please provide script with .po file"
    exit 123
}

[ $1 == "--help" ] && {
    echo "./translate.sh [file.po]"
    exit 1
}

file=$1
echo "Working with $file"

#cat $file | sed -n '/msgid/,/msgstr/p' | grep -v "msgstr \"" > ./result.po

# Shows whether the translation started
tran=0
line_number=0

while read -r line;
do
    line_number=`expr $line_number \+ 1`
    echo "line = $line ($line_number)"
    
    if [ $line_number -eq 7 ]
    then echo "AAAAAAAAAAA" >> xxx.txt
	sed -n "$line_number,+10p" $file | sed '/msgstr ""/q' | grep -v "msgstr \"\"" >> xxx.txt
	echo "AAAAAAAAAAA" >> xxx.txt
    else echo $line >> ./xxx.txt
    fi

done < $file