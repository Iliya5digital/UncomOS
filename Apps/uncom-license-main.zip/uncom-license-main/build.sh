#!/bin/sh

# current_dir=`pwd`
file=`ls ./*.tar.xz`
name=`echo $file | awk -F _ '{print $1}'`
echo "Rebuilding $name"
tar -xf $file
cd $name && {
dpkg-buildpackage 2>&1 | grep "" > $current_dir/$name.build.log
cd $current_dir
}

ls -l *.deb ; code=$?
if [ $code -eq 0 ]
then echo "Build seems OK, log: $current_dir/$name.build.log"
else echo "Build seems to FAIL, log: $current_dir/$name.build.log"
fi
