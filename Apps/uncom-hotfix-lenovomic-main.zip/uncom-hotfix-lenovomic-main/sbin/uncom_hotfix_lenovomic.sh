#!/bin/bash

Green='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${Green}Starting the script...${NC}"
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

hits=`cat /etc/default/grub | grep "quiet splash" | grep -v "snd_rn_pci_acp3x.dmic_acpi_check=" | wc -l`
if [ $hits == "1" ]
then sed -i "s/quiet splash/quiet splash snd_rn_pci_acp3x.dmic_acpi_check=1/" /etc/default/grub
    update-grub
    echo -e "${GREEN}Now you should reboot the computer${NC}"
else echo -e "${RED}Something wrong, please contact the support${NC}"
fi


