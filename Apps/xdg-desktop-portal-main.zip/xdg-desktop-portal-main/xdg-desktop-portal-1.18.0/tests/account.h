#pragma once

void test_account_basic (void);
void test_account_delay (void);
void test_account_cancel (void);
void test_account_close (void);
void test_account_parallel (void);
void test_account_reason (void);
