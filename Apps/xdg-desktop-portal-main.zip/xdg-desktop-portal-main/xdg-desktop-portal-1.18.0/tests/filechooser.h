#pragma once

void test_open_file_basic (void);
void test_open_file_delay (void);
void test_open_file_cancel (void);
void test_open_file_close (void);
void test_open_file_multiple (void);
void test_open_file_filters1 (void);
void test_open_file_filters2 (void);
void test_open_file_current_filter1 (void);
void test_open_file_current_filter2 (void);
void test_open_file_current_filter3 (void);
void test_open_file_current_filter4 (void);
void test_open_file_choices1 (void);
void test_open_file_choices2 (void);
void test_open_file_choices3 (void);
void test_open_file_parallel (void);

void test_save_file_basic (void);
void test_save_file_delay (void);
void test_save_file_cancel (void);
void test_save_file_close (void);
void test_save_file_filters (void);
void test_save_file_lockdown (void);
void test_save_file_parallel (void);
