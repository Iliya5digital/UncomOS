#pragma once

void test_camera_basic (void);
void test_camera_delay (void);
void test_camera_cancel (void);
void test_camera_close (void);
void test_camera_lockdown (void);
void test_camera_no_access1 (void);
void test_camera_no_access2 (void);
void test_camera_parallel (void);
