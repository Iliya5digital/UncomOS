void test_web_extensions_basic (void);
void test_web_extensions_bad_name (void);
