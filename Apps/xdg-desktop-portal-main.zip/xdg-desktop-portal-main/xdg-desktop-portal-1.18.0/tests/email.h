#pragma once

void test_email_basic (void);
void test_email_address (void);
void test_email_punycode_address (void);
void test_email_subject (void);
void test_email_delay (void);
void test_email_cancel (void);
void test_email_close (void);
void test_email_parallel (void);
