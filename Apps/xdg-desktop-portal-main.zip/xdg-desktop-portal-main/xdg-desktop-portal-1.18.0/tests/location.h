#pragma once

void test_location_basic (void);
void test_location_accuracy (void);
