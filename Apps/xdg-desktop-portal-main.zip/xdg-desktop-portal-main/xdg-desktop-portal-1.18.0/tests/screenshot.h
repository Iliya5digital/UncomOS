#pragma once

void test_screenshot_basic (void);
void test_screenshot_delay (void);
void test_screenshot_cancel (void);
void test_screenshot_close (void);
void test_screenshot_parallel (void);

void test_color_basic (void);
void test_color_delay (void);
void test_color_cancel (void);
void test_color_close (void);
void test_color_parallel (void);
