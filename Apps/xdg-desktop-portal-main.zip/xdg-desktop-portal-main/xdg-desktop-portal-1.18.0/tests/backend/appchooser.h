#pragma once

void appchooser_init (GDBusConnection *connection, const char *object_path);
