#pragma once

void email_init (GDBusConnection *bus, const char *object_path);
