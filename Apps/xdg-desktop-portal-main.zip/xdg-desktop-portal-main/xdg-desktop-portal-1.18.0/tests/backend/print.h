#pragma once

void print_init (GDBusConnection *connection, const char *object_path);
