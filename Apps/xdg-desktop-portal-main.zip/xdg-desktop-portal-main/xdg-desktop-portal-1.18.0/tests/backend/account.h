#pragma once

void account_init (GDBusConnection *connection, const char *object_path);
