#!/bin/bash

Green='\033[0;32m'
NC='\033[0m' # No Color

echo -e "${Green}Starting the script...${NC}"
mkdir -p /etc/xdg/autostart/
cat  <<EOF > /etc/xdg/autostart/gesture.desktop
[Desktop Entry]
Type=Application
Exec=/usr/bin/gesturedisable.sh
Hidden=false
X-GNOME-Autostart-enabled=true
Name=run_gesture_disable
Comment=run_gd
EOF

cat <<EOF > /usr/bin/gesturedisable.sh
#!/bin/bash
xinput list --name-only | grep ^xwayland-pointer-gestures | xargs -n1 xinput disable
EOF

chmod +x /usr/bin/gesturedisable.sh
