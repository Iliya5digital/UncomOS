#ifndef QPDF_XOBJECT_H_
#define QPDF_XOBJECT_H_

#include <qpdf/QPDFObjectHandle.hh>

QPDFObjectHandle makeXObject(QPDF *pdf,QPDFObjectHandle page);

#endif
