#ifndef _IOFN_H
#define _IOFN_H

typedef void (*OUTPUT_FN)(const char *buf,int len,void *context);

#endif
