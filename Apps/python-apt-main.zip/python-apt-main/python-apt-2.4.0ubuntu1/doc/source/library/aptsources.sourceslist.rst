:mod:`aptsources.sourceslist` --- Provide an abstraction of the sources.list
============================================================================
.. note::

    This part of the documentation is created automatically.


.. automodule:: aptsources.sourceslist
    :members:
    :undoc-members:

