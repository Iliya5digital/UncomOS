:mod:`apt.cdrom` - Functionality like in apt-cdrom
====================================================
.. automodule:: apt.cdrom
    :members:



