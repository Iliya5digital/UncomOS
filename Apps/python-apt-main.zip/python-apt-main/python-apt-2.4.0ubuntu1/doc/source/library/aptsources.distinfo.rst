:mod:`aptsources.distinfo` --- provide meta information for distro repositories
===============================================================================
.. note::

    This part of the documentation is created automatically.


.. automodule:: aptsources.distinfo
    :members:
    :undoc-members:

