scp *.html *.css hughsient@annarchy.freedesktop.org:/srv/www.freedesktop.org/www/software/colord/
scp ../api/html/* hughsient@annarchy.freedesktop.org:/srv/www.freedesktop.org/www/software/colord/gtk-doc/
